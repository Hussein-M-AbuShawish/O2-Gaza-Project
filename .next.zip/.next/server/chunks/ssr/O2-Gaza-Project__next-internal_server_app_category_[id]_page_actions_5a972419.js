module.exports=[47166,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_category_%5Bid%5D_page_actions_5a972419.js.map