module.exports=[12513,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_categories_page_actions_62f38c2b.js.map