module.exports=[69816,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_about_page_actions_70b565d9.js.map