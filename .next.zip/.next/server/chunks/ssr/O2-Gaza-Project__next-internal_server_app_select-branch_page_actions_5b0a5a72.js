module.exports=[30138,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_select-branch_page_actions_5b0a5a72.js.map