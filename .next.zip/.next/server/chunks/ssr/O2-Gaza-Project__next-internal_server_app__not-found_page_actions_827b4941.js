module.exports=[67892,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app__not-found_page_actions_827b4941.js.map