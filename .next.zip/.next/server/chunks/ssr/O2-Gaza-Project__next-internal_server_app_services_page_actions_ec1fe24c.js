module.exports=[89212,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_services_page_actions_ec1fe24c.js.map