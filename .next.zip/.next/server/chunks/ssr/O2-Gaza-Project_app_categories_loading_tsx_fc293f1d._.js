module.exports=[20169,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=O2-Gaza-Project_app_categories_loading_tsx_fc293f1d._.js.map