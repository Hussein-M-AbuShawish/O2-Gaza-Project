module.exports=[19873,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_menu_page_actions_963d9150.js.map