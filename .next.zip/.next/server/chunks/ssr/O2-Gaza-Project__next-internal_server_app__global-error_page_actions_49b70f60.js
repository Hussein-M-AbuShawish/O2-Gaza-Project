module.exports=[95688,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app__global-error_page_actions_49b70f60.js.map