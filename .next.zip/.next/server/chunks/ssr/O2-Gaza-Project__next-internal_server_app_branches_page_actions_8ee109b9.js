module.exports=[35028,(a,b,c)=>{}];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_branches_page_actions_8ee109b9.js.map