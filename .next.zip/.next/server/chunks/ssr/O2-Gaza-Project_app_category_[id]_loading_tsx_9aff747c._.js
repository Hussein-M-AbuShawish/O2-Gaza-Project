module.exports=[48929,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=O2-Gaza-Project_app_category_%5Bid%5D_loading_tsx_9aff747c._.js.map