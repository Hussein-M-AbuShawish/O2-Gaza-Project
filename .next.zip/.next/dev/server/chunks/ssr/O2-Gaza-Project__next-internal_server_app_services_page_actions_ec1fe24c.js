module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/services/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_services_page_actions_ec1fe24c.js.map