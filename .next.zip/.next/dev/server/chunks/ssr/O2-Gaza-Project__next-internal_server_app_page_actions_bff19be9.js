module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_page_actions_bff19be9.js.map