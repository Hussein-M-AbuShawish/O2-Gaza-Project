module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/select-branch/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_select-branch_page_actions_5b0a5a72.js.map