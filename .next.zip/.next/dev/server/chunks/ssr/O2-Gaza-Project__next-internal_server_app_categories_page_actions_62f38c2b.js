module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/categories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_categories_page_actions_62f38c2b.js.map