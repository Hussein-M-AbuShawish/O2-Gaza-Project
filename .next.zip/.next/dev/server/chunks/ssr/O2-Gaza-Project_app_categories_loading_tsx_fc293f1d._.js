module.exports = [
"[project]/O2-Gaza-Project/app/categories/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=O2-Gaza-Project_app_categories_loading_tsx_fc293f1d._.js.map