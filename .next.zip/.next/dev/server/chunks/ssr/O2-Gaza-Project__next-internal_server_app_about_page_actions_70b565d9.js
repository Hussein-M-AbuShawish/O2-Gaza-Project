module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/about/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_about_page_actions_70b565d9.js.map