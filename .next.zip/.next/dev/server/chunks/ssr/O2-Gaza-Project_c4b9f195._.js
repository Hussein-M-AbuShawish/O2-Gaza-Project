module.exports = [
"[project]/O2-Gaza-Project/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/O2-Gaza-Project/components/ui/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: 'bg-primary text-primary-foreground hover:bg-primary/90',
            destructive: 'bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
            outline: 'border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50',
            secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
            ghost: 'hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50',
            link: 'text-primary underline-offset-4 hover:underline'
        },
        size: {
            default: 'h-9 px-4 py-2 has-[>svg]:px-3',
            sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5',
            lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
            icon: 'size-9',
            'icon-sm': 'size-8',
            'icon-lg': 'size-10'
        }
    },
    defaultVariants: {
        variant: 'default',
        size: 'default'
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/components/ui/button.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/O2-Gaza-Project/components/navbar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Navbar",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
"use client";
;
;
;
;
;
;
const navLinks = [
    {
        href: "/about",
        label: "من نحن"
    },
    {
        href: "/services",
        label: "أنشطتنا"
    },
    {
        href: "/select-branch",
        label: "اطلب الان"
    },
    {
        href: "#reviews",
        label: "آراء العملاء"
    },
    {
        href: "#contact",
        label: "تواصل معنا"
    }
];
function Navbar() {
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleScroll = ()=>{
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].nav, {
                initial: {
                    y: -100
                },
                animate: {
                    y: 0
                },
                transition: {
                    duration: 0.5
                },
                className: `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? "bg-background/80 backdrop-blur-lg border-b border-border/50 shadow-lg" : "bg-transparent"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between h-16 md:h-20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "flex items-center gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-3xl md:text-4xl font-bold",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-foreground",
                                            children: "Gaza"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 45,
                                            columnNumber: 17
                                        }, this),
                                        " ",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "o2-logo-red text-primary",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "2"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 19
                                                }, this),
                                                "0"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 46,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 44,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden lg:flex items-center gap-1",
                                children: navLinks.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: link.href,
                                        className: "px-4 py-2 text-muted-foreground hover:text-foreground transition-colors text-sm font-medium",
                                        children: link.label
                                    }, link.href, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 55,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden lg:block",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                    asChild: true,
                                    className: "bg-primary text-primary-foreground hover:bg-primary/90",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/select-branch",
                                        target: "_blank",
                                        children: "اطلب الآن"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 71,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 67,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "lg:hidden p-2 text-foreground",
                                onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                                "aria-label": isMobileMenuOpen ? "إغلاق القائمة" : "فتح القائمة",
                                children: isMobileMenuOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 24
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 87,
                                    columnNumber: 35
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                    size: 24
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 87,
                                    columnNumber: 53
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 81,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        y: -20
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    exit: {
                        opacity: 0,
                        y: -20
                    },
                    transition: {
                        duration: 0.2
                    },
                    className: "fixed inset-0 z-40 lg:hidden",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0 bg-background/95 backdrop-blur-lg",
                            onClick: ()=>setIsMobileMenuOpen(false),
                            onKeyDown: (e)=>e.key === "Escape" && setIsMobileMenuOpen(false)
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                            lineNumber: 103,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            transition: {
                                delay: 0.1
                            },
                            className: "relative pt-24 px-6 flex flex-col gap-4",
                            children: [
                                navLinks.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                        initial: {
                                            opacity: 0,
                                            x: -20
                                        },
                                        animate: {
                                            opacity: 1,
                                            x: 0
                                        },
                                        transition: {
                                            delay: index * 0.05
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: link.href,
                                            className: "block py-3 text-xl text-foreground hover:text-primary transition-colors border-b border-border/50",
                                            onClick: ()=>setIsMobileMenuOpen(false),
                                            children: link.label
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 123,
                                            columnNumber: 19
                                        }, this)
                                    }, link.href, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 117,
                                        columnNumber: 17
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                    initial: {
                                        opacity: 0,
                                        x: -20
                                    },
                                    animate: {
                                        opacity: 1,
                                        x: 0
                                    },
                                    transition: {
                                        delay: navLinks.length * 0.05
                                    },
                                    className: "mt-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                        asChild: true,
                                        className: "w-full bg-primary text-primary-foreground hover:bg-primary/90",
                                        size: "lg",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/select-branch",
                                            target: "_blank",
                                            children: "اطلب الآن"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 143,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                            lineNumber: 110,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                    lineNumber: 96,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/O2-Gaza-Project/components/footer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Footer",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/facebook.js [app-ssr] (ecmascript) <export default as Facebook>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/instagram.js [app-ssr] (ecmascript) <export default as Instagram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/twitter.js [app-ssr] (ecmascript) <export default as Twitter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$youtube$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Youtube$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/youtube.js [app-ssr] (ecmascript) <export default as Youtube>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/phone.js [app-ssr] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/mail.js [app-ssr] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-ssr] (ecmascript) <export default as MapPin>");
"use client";
;
;
;
;
const quickLinks = [
    {
        href: "/about",
        label: "من نحن"
    },
    {
        href: "/services",
        label: "خدماتنا"
    },
    {
        href: "/categories",
        label: "قائمتنا"
    },
    {
        href: "#contact",
        label: "تواصل معنا"
    }
];
const socialLinks = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__["Facebook"],
        href: "#",
        label: "فيسبوك"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__["Instagram"],
        href: "#",
        label: "إنستغرام"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__["Twitter"],
        href: "#",
        label: "تويتر"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$youtube$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Youtube$3e$__["Youtube"],
        href: "#",
        label: "يوتيوب"
    }
];
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-card border-t border-border/50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 py-12 md:py-16",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 items-start",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5
                            },
                            viewport: {
                                once: true
                            },
                            className: "lg:col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "inline-block mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-3xl font-bold",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-foreground",
                                                children: "Gaza"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 45,
                                                columnNumber: 17
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "o2-logo-red text-primary",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                        lineNumber: 47,
                                                        columnNumber: 19
                                                    }, this),
                                                    "0"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 46,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                        lineNumber: 44,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-muted-foreground leading-relaxed mb-6",
                                    children: "تجربة طعام استثنائية تجمع بين الأصالة والحداثة، حيث نقدم لكم أشهى المأكولات في أجواء راقية."
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-3",
                                    children: socialLinks.map((social)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: social.href,
                                            "aria-label": social.label,
                                            className: "w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(social.icon, {
                                                className: "w-5 h-5"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 64,
                                                columnNumber: 19
                                            }, this)
                                        }, social.label, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 58,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.1
                            },
                            viewport: {
                                once: true
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-foreground mb-4",
                                    children: "روابط سريعة"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3",
                                    children: quickLinks.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: link.href,
                                                className: "text-muted-foreground hover:text-primary transition-colors",
                                                children: link.label
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 83,
                                                columnNumber: 19
                                            }, this)
                                        }, link.href, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.2
                            },
                            viewport: {
                                once: true
                            },
                            className: "lg:col-span-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-foreground mb-4",
                                    children: "فروعنا"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-6 flex justify-between md:justify-start lg:justify-normal",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "lg:col-span-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold mb-4 text-primary",
                                                    children: "فرع غزة"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 104,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                    className: "space-y-3 text-sm text-muted-foreground",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 107,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " مدينة غزة، شارع النصر"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 106,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            dir: "rtl",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 110,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    dir: "ltr",
                                                                    children: "+972 59 711 1811"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 111,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 109,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 114,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " info@o2gaza.com"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 113,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 105,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 103,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "lg:col-span-1 lg:ms-20 :ml-30 xl:ms-32 transition-all",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold mb-4 text-primary",
                                                    children: "فرع النصيرات"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 120,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                    className: "space-y-3 text-sm text-muted-foreground",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 125,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " النصيرات، مفترق ابو صرار"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 124,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            dir: "rtl",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 128,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    dir: "ltr",
                                                                    children: "+972 59 711 1811"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 129,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 127,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 132,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " info@o2gaza.com"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 131,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 123,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 119,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 102,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 94,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.3
                            },
                            viewport: {
                                once: true
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-foreground mb-4",
                                    children: "ساعات العمل"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3 text-muted-foreground",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "جميع أيام الاسبوع"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 151,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "10:00 ص - 12:00 م"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 152,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 140,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0
                    },
                    whileInView: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.5,
                        delay: 0.4
                    },
                    viewport: {
                        once: true
                    },
                    className: "mt-12 pt-8 border-t border-border/50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row justify-between items-center gap-4 text-muted-foreground text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "جميع الحقوق محفوظة © ",
                                    new Date().getFullYear(),
                                    " مطعم O2 Gaza"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                lineNumber: 167,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "تم تطويره بواسطة فريق 02 المميز"
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                lineNumber: 170,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                        lineNumber: 166,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                    lineNumber: 159,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
            lineNumber: 32,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
}),
"[project]/O2-Gaza-Project/lib/menu-data.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Branch-specific menu data
// Each branch has its own independent menu with all categories
__turbopack_context__.s([
    "branchMenuData",
    ()=>branchMenuData,
    "categoryNames",
    ()=>categoryNames,
    "getCategoryByBranch",
    ()=>getCategoryByBranch,
    "getMenuByBranch",
    ()=>getMenuByBranch
]);
const categoryNames = {
    shawarma: "الشاورما",
    italian: "الإيطالي",
    sandwiches: "السندويشات الغربية",
    easternSweets: "الحلويات الشرقية",
    westernSweets: "الكيك والحلويات الغربية",
    barSweets: "حلويات البار",
    drinks: "المشروبات",
    salads: "السلطات",
    gelato: "الجيلاتو"
};
// Helper to apply default value for active
function withDefaultActive(items) {
    return items.map((item)=>({
            ...item,
            active: item.active ?? true
        }));
}
// Gaza Branch Menu
const gazaMenu = {
    shawarma: {
        title: "الشاورما",
        items: withDefaultActive([
            {
                name: "بيتا شاورما",
                price: 10,
                image: "/menu/shawarma/54.jpg"
            },
            {
                name: "شاورما عادي",
                price: 15,
                image: "/menu/shawarma/48.jpg",
                active: true
            },
            {
                name: "فرشوحه دبل",
                price: 17,
                image: "/menu/shawarma/49.jpg"
            },
            {
                name: "فرشوحه دبل لحمة",
                price: 23,
                image: "/menu/shawarma/48.jpg"
            },
            {
                name: "فرشوحه دبل دبل",
                price: 25,
                image: "/menu/shawarma/48.jpg",
                delivery: false
            },
            {
                name: "سوري",
                price: 28,
                image: "/menu/shawarma/53.jpg"
            },
            {
                name: "صفيحة",
                price: 30,
                desc: "شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/51.jpg"
            },
            {
                name: "باشكا",
                price: 40,
                desc: "خبزة باشكا - شاورما - جبنة - زيتون - صوص بيكانتي",
                image: "/menu/shawarma/18.jpg"
            },
            {
                name: "شاورما عربي",
                price: 30,
                desc: "قطع شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/17.jpg"
            },
            {
                name: "شاورما نابلسي",
                price: 30,
                desc: "شاورما - بطاطا - صوص بيكانتي - جبنة - زيتون اسود",
                image: "/menu/shawarma/19.jpg"
            },
            {
                name: "صحن شاورما كبير",
                price: 30,
                image: "/menu/shawarma/14.jpg"
            },
            {
                name: "صحن شاورما صغير",
                price: 20,
                image: "/menu/shawarma/13.jpg"
            }
        ])
    },
    italian: {
        title: "الإيطالي",
        items: withDefaultActive([
            {
                name: "كاليزوني دجاج",
                price: 30,
                desc: "صدر دجاج - جبنة - زيتون - رانش",
                image: "/menu/italian/35.jpg"
            },
            {
                name: "كاليزوني خضار",
                price: 15,
                desc: "فليفلة - بصل - ذرة - مشروم - زيتون",
                image: "/menu/italian/32.jpg"
            },
            {
                name: "بيتزا مكسيكي دجاج",
                price: 20,
                desc: "صدر دجاج - جبنة - زيتون",
                image: "/menu/italian/33.jpg"
            },
            {
                name: "ميجا",
                price: 30,
                desc: "صدر دجاج - فليفلة - مشروم - جرادة - بصل - كريمة طعام",
                image: "/menu/italian/34.jpg"
            },
            {
                name: "بيتزا",
                price: 15,
                desc: "خضار - ذرة - زيتون",
                image: "/menu/italian/32.jpg"
            },
            {
                name: "بيتزا ماما روزا بالاناناس",
                price: 15,
                desc: "أناناس",
                image: "/menu/italian/2.jpg"
            },
            {
                name: "نابولي",
                price: 15,
                desc: "بيتزا بالتونة والزيتون",
                image: "/menu/italian/3.jpg"
            },
            {
                name: "مارجريتا",
                price: 15,
                desc: "جبنة",
                image: "/menu/italian/1.jpg"
            },
            {
                name: "صوص إضافي",
                price: 3,
                image: "https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&q=80"
            }
        ])
    },
    sandwiches: {
        title: "السندويشات الغربية",
        items: withDefaultActive([
            {
                name: "زينجر",
                price: 25,
                desc: "شرائح صدر دجاج متبّلة مع بندورة طازجة، جرجير، حلقات بصل",
                image: "/menu/western/44.jpg"
            },
            {
                name: "بيف برجر",
                price: 25,
                desc: "قطعة لحمة - بصل - بندورة - جبنة - مخلل - صوص بيكانتي",
                image: "/menu/western/40.jpg"
            },
            {
                name: "بيغ ماك",
                price: 35,
                desc: "قطعتين لحمة - بصل - بندورة - جبنة - مخلل - صوص بيكانتي",
                image: "/menu/western/46.jpg"
            },
            {
                name: "تشكن بيتزا",
                price: 25,
                desc: "صدر دجاج - مشروم - فليفلة - بصل - زيتون اسود - جبنة",
                image: "/menu/western/42.jpg"
            },
            {
                name: "شيش طاووق",
                price: 25,
                desc: "فخد دجاج - جرجير - بندورة -مخلل -صوص بيكانتي",
                image: "/menu/western/47.jpg"
            },
            {
                name: "فطيرة الذهبية",
                price: 25,
                desc: "صدر دجاج - فليفلة - بصل - زيتون اسود - جبنة - ذرة - كريمة طعام",
                image: "/menu/western/43.jpg"
            }
        ])
    },
    easternSweets: {
        title: "الحلويات الشرقية",
        byWeight: true,
        items: withDefaultActive([
            {
                name: "نمورة",
                pricePerKg: 15,
                image: "/menu/sweets/25.jpeg"
            },
            {
                name: "بسبوسة",
                pricePerKg: 20,
                image: "/menu/sweets/81.jpeg"
            },
            {
                name: "كلاج",
                pricePerKg: 20,
                image: "/menu/sweets/3.1.jpg"
            },
            {
                name: "عش البلبل",
                pricePerKg: 30,
                image: "/menu/sweets/7.jpg"
            },
            {
                name: "نابلسية",
                pricePerKg: 60,
                image: "/menu/sweets/23.jpg"
            },
            {
                name: "كنافة عربية",
                pricePerKg: 40,
                image: "/menu/sweets/11.jpg"
            },
            {
                name: "معكوفة لوز",
                pricePerKg: 35,
                image: "/menu/sweets/6.jpg"
            },
            {
                name: "كول واشكر",
                pricePerKg: 30,
                image: "/menu/sweets/5.jpg"
            },
            {
                name: "سنيورة",
                pricePerKg: 30,
                image: "/menu/sweets/8.jpg"
            },
            {
                name: "سرة",
                pricePerKg: 35,
                image: "/menu/sweets/2.jpg"
            },
            {
                name: "وربات",
                pricePerKg: 35,
                image: "/menu/sweets/2.jpg"
            },
            {
                name: "معكوفة عين جمل",
                pricePerKg: 35,
                image: "/menu/sweets/26.jpg"
            },
            {
                name: "بسبوسة نوتيلا",
                pricePerKg: 40,
                image: "/menu/sweets/18.jpeg"
            },
            {
                name: "بقلاوة عين جمل",
                pricePerKg: 55,
                image: "/menu/sweets/41.jpg"
            },
            {
                name: "بقلاوة لوز",
                pricePerKg: 48,
                image: "/menu/sweets/9.jpg"
            },
            {
                name: "بقلاوة حلبي",
                pricePerKg: 100,
                image: "/menu/sweets/10.jpg"
            },
            {
                name: "أساور لوز",
                pricePerKg: 48,
                image: "/menu/sweets/19.jpeg"
            },
            {
                name: "كاسات مكسرات",
                pricePerKg: 80,
                image: "/menu/sweets/24.jpg"
            },
            {
                name: "بورما حلبي",
                pricePerKg: 100,
                image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=800&q=80",
                active: false
            },
            {
                name: "بلورية حلبي",
                pricePerKg: 130,
                image: "https://images.unsplash.com/photo-1571167530149-c6f274f6db8f?w=800&q=80",
                active: false
            },
            {
                name: "دولمة حلبي",
                pricePerKg: 130,
                image: "/menu/sweets/27.jpg"
            }
        ])
    },
    westernSweets: {
        title: "الكيك والحلويات الغربية",
        items: withDefaultActive([
            {
                name: "قالب كيك صغير",
                price: 60,
                image: "/menu/cake/9.jpg"
            },
            {
                name: "قالب كيك كبير",
                price: 80,
                image: "/menu/cake/10.jpg"
            },
            {
                name: "قالب كيك اسبيسشل صغير",
                price: 80,
                image: "/menu/cake/38.jpg"
            },
            {
                name: "قالب كيك اسبيسشل كبير",
                price: 100,
                image: "/menu/cake/38.jpg"
            },
            {
                name: "سويس رول",
                price: 8,
                image: "/menu/cake/31.jpg"
            },
            {
                name: "تريلتشا",
                price: 10,
                image: "/menu/cake/21.jpg"
            },
            {
                name: "قطع كيك كلاسيكي",
                price: 5,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/cake/30.jpg"
            },
            {
                name: "قطع كيك سبيشل",
                price: 10,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/cake/30.jpg"
            },
            {
                name: "سوبريم",
                price: 18,
                desc: "لوتس - نوتيلا - بيستاشيو",
                image: "/menu/cake/28.jpg"
            },
            {
                name: "موس",
                price: 15,
                desc: "كيندر- لوتس - نوتيلا - بيستاشيو",
                image: "/menu/cake/4.jpg"
            },
            {
                name: "تشيس كيك",
                price: 15,
                image: "/menu/cake/7.jpg"
            },
            {
                name: "كرانش بار",
                price: 15,
                image: "/menu/cake/23.jpg"
            },
            {
                name: "قالب نص بلاطة",
                price: 150,
                image: "/menu/cake/8.1.jpg"
            }
        ])
    },
    barSweets: {
        title: "حلويات البار",
        items: withDefaultActive([
            {
                name: "كريب شوكولاتة",
                price: 15,
                image: "/menu/bar/16.jpg"
            },
            {
                name: "كريب (نوتيلا / بيستاشيو / لوتس)",
                price: 25,
                image: "/menu/bar/64.jpg"
            },
            {
                name: "كريب دبي",
                price: 30,
                image: "/menu/bar/14.jpg"
            },
            {
                name: "بان كيك",
                price: 30,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/bar/13.jpg"
            },
            {
                name: "رينجز",
                price: 25,
                image: "/menu/bar/56.jpg"
            },
            {
                name: "لقيمات شوكولاتة",
                price: 15,
                image: "/menu/bar/15.jpg"
            },
            {
                name: "لقيمات (نوتيلا / بيستاشيو / لوتس)",
                price: 25,
                image: "/menu/bar/55.jpg"
            },
            {
                name: "بان كيك شوكولاتة",
                price: 15,
                image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800&q=80"
            },
            {
                name: "مولتن كيك",
                price: 20,
                image: "/menu/bar/37.jpg"
            },
            {
                name: "هوت كيك",
                price: 20,
                image: "/menu/bar/59.jpg"
            },
            {
                name: "براونيز",
                price: 20,
                image: "/menu/bar/38.jpg"
            },
            {
                name: "ترياكي",
                price: 25,
                image: "/menu/bar/38.jpg"
            },
            {
                name: "ميني فيشز",
                price: 25,
                image: "/menu/bar/38.jpg",
                desc: "نوتيلا / بيستاشيو / لوتس"
            },
            {
                name: "ميني بان كيك",
                price: 25,
                image: "/menu/bar/38.jpg",
                desc: "نوتيلا / بيستاشيو / لوتس"
            },
            {
                name: "وافل ستيك",
                price: 25,
                image: "/menu/bar/38.jpg",
                desc: "نوتيلا / بيستاشيو / لوتس"
            },
            {
                name: "كنافة نويتلا",
                price: 15,
                image: "/menu/bar/58.jpg"
            }
        ])
    },
    gelato: {
        title: "الجيلاتو",
        items: withDefaultActive([
            {
                name: "جيلاتو نوتيلا",
                price: 15,
                image: "/menu/Gelato/70.jpeg"
            },
            {
                name: "جيلاتو بستاشيو",
                price: 15,
                image: "/menu/Gelato/72.jpeg"
            },
            {
                name: "جيلاتو لوتس",
                price: 15,
                image: "/menu/Gelato/70.jpeg"
            },
            {
                name: "جيلاتو كيندر",
                price: 15,
                image: "/menu/Gelato/70.jpeg"
            },
            {
                name: "جيلاتو بلوبيري",
                price: 15,
                image: "/menu/Gelato/79.jpeg"
            },
            {
                name: "جيلاتو عربية",
                price: 15,
                image: "/menu/Gelato/75.jpeg"
            }
        ])
    },
    drinks: {
        title: "المشروبات",
        items: withDefaultActive([
            {
                name: "عصير الموسم",
                price: 10,
                image: "/menu/drinks/1.jpg"
            },
            {
                name: "عصير أناناس",
                price: 12,
                image: "/menu/drinks/2.jpg"
            },
            {
                name: "ليمون ونعنع",
                price: 10,
                image: "/menu/drinks/3.jpg"
            },
            {
                name: "أفوكادو",
                price: 15,
                image: "/menu/drinks/4.jpg"
            },
            {
                name: "شوكو بارد",
                price: 10,
                image: "/menu/drinks/7.jpg"
            },
            {
                name: "ايس موكا",
                price: 10,
                image: "/menu/drinks/5.jpg"
            },
            {
                name: "آيس كافي",
                price: 10,
                image: "/menu/drinks/10.jpg"
            },
            {
                name: "ميلك شيك",
                price: 15,
                image: "/menu/drinks/8.jpg"
            },
            {
                name: "موهيتو",
                price: 20,
                image: "/menu/drinks/16.jpg"
            },
            {
                name: "آيس كريم",
                price: 10,
                image: "/menu/drinks/14.jpg"
            },
            {
                name: "براد",
                price: 5,
                image: "/menu/drinks/15.jpg"
            },
            {
                name: "نسكافيه",
                price: 5,
                image: "/menu/drinks/9.jpg"
            },
            {
                name: "كابتشينو",
                price: 5,
                image: "/menu/drinks/9.jpg"
            },
            {
                name: "اسبريسو سينجل",
                price: 5,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: "اسبريسو دبل",
                price: 10,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: " قهوة تركي سينجل",
                price: 5,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: "قهوة تركي دبل",
                price: 10,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: "شاي",
                price: 3,
                image: "/menu/drinks/11.jpg"
            },
            {
                name: "بلو",
                price: 4,
                image: "/menu/drinks/17.jpg"
            },
            {
                name: "كوكا كولا",
                price: 5,
                image: "/menu/drinks/18.jpg"
            },
            {
                name: "سبرايت",
                price: 5,
                image: "/menu/drinks/19.jpg"
            },
            {
                name: "مياه معدنية 200 ملم",
                price: 1,
                image: "/menu/drinks/12.jpg"
            },
            {
                name: "مياه معدنية 500 ملم",
                price: 2,
                image: "/menu/drinks/13.jpg"
            }
        ])
    },
    salads: {
        title: "السلطات",
        items: withDefaultActive([
            {
                name: "سلطات كبيرة",
                price: 15,
                image: "/menu/salad/1.jpeg",
                desc: "ذرة مايونيز / بيكانتي / تركية / ثومية"
            },
            {
                name: "سلطات وسط",
                price: 10,
                image: "/menu/salad/2.jpeg"
            },
            {
                name: "سلطات صغيرة",
                price: 5,
                image: "/menu/salad/1.jpeg"
            },
            {
                name: "بطاطا كبيرة",
                price: 10,
                image: "/menu/salad/20.jpeg"
            },
            {
                name: "بطاطا صغيرة",
                price: 5,
                image: "/menu/salad/20.jpeg"
            }
        ])
    }
};
// Middle Branch Menu (initially same as Gaza, but can be modified independently)
const middleMenu = {
    shawarma: {
        title: "الشاورما",
        items: [
            {
                name: "بيتا شاورما",
                price: 50,
                image: "/menu/shawarma/54.jpg"
            },
            {
                name: "شاورما عادي",
                price: 15,
                image: "/menu/shawarma/48.jpg"
            },
            {
                name: "فرشوحه دبل",
                price: 17,
                image: "/menu/shawarma/5O1A7108.jpg"
            },
            {
                name: "فرشوحه دبل لحمة",
                price: 23,
                image: "/menu/shawarma/5O1A7124.jpg"
            },
            {
                name: "فرشوحه دبل دبل",
                price: 25,
                image: "https://images.unsplash.com/photo-1542574271-7f3b92e6c821?w=800&q=80",
                delivery: false
            },
            {
                name: "سوري",
                price: 35,
                image: "/menu/shawarma/53.jpg"
            },
            {
                name: "صفيحة",
                price: 38,
                desc: "شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/51.jpg"
            },
            {
                name: "باشكا",
                price: 40,
                desc: "خبزة باشكا - شاورما - جبنة - زيتون - صوص بيكانتي",
                image: "/menu/shawarma/18.jpg"
            },
            {
                name: "شاورما عربي",
                price: 38,
                desc: "قطع شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/17.jpg"
            },
            {
                name: "شاورما نابلسي",
                price: 38,
                desc: "شاورما - بطاطا - صوص بيكانتي - جبنة - زيتون اسود",
                image: "/menu/shawarma/19.jpg"
            },
            {
                name: "صحن شاورما كبير",
                price: 30,
                image: "/menu/shawarma/14.jpg"
            },
            {
                name: "صحن شاورما صغير",
                price: 20,
                image: "/menu/shawarma/13.jpg"
            }
        ]
    },
    italian: gazaMenu.italian,
    sandwiches: gazaMenu.sandwiches,
    easternSweets: gazaMenu.easternSweets,
    westernSweets: gazaMenu.westernSweets,
    barSweets: gazaMenu.barSweets,
    drinks: gazaMenu.drinks,
    salads: gazaMenu.salads
};
const branchMenuData = {
    gaza: gazaMenu,
    middle: middleMenu
};
function getMenuByBranch(branch) {
    return branchMenuData[branch] || branchMenuData.gaza;
}
function getCategoryByBranch(branch, categoryId) {
    const menu = getMenuByBranch(branch);
    return menu[categoryId] || null;
}
}),
"[project]/O2-Gaza-Project/public/menu/Shawarma/18.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/18.9e67ccd2.jpg");}),
"[project]/O2-Gaza-Project/public/menu/Shawarma/18.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Shawarma/18.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Shawarma$2f$18$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Shawarma/18.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Shawarma$2f$18$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDkbaC2OmPA1nbkAA7zGN2c+tcVne9zrvpax//Z"
};
}),
"[project]/O2-Gaza-Project/public/menu/Italian/35.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/35.594a52fa.jpg");}),
"[project]/O2-Gaza-Project/public/menu/Italian/35.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Italian/35.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Italian$2f$35$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Italian/35.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Italian$2f$35$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDz3Tr2WWylicIRa4aE4wUORz9eK45xUZprqdkJOUHfpsf/2Q=="
};
}),
"[project]/O2-Gaza-Project/public/menu/Western/43.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/43.ad9fc681.jpg");}),
"[project]/O2-Gaza-Project/public/menu/Western/43.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Western/43.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Western$2f$43$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Western/43.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Western$2f$43$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDkDfT3Gk2enykNA8fQjJH0NedTpx9rKR31JtU0u5//2Q=="
};
}),
"[project]/O2-Gaza-Project/public/menu/Sweets/27.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/27.da1cb5fb.jpg");}),
"[project]/O2-Gaza-Project/public/menu/Sweets/27.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Sweets/27.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Sweets$2f$27$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Sweets/27.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Sweets$2f$27$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDzwWttsaE28ZAUvux82frXNd9zeyuf/9k="
};
}),
"[project]/O2-Gaza-Project/public/menu/Bar/16.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/16.efc88d53.jpg");}),
"[project]/O2-Gaza-Project/public/menu/Bar/16.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Bar/16.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Bar$2f$16$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Bar/16.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Bar$2f$16$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDh1tbU6NsNrFnbu37fmz9a57vY3sr3P//Z"
};
}),
"[project]/O2-Gaza-Project/public/menu/Cake/11.2.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/11.2.76f6436b.jpg");}),
"[project]/O2-Gaza-Project/public/menu/Cake/11.2.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Cake/11.2.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Cake$2f$11$2e$2$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Cake/11.2.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Cake$2f$11$2e$2$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDzu+ggggaJIIwrHPI5z9etYXdzdpcp/9k="
};
}),
"[project]/O2-Gaza-Project/public/menu/drinks/13.jpg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/13.a582a72a.jpg");}),
"[project]/O2-Gaza-Project/public/menu/drinks/13.jpg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/drinks/13.jpg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$drinks$2f$13$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/drinks/13.jpg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$drinks$2f$13$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDzh9Ptxp23B5YtnPPpWHOzZwVz/9k="
};
}),
"[project]/O2-Gaza-Project/public/menu/salad/20.jpeg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/20.bf4caad5.jpeg");}),
"[project]/O2-Gaza-Project/public/menu/salad/20.jpeg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/salad/20.jpeg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$salad$2f$20$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/salad/20.jpeg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$salad$2f$20$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDj4bOyfw2yNY25cf8ALXZ8/r1/SuXW97nTpa1j/9k="
};
}),
"[project]/O2-Gaza-Project/public/menu/Gelato/72.jpeg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/72.6c844946.jpeg");}),
"[project]/O2-Gaza-Project/public/menu/Gelato/72.jpeg.mjs { IMAGE => \"[project]/O2-Gaza-Project/public/menu/Gelato/72.jpeg (static in ecmascript, tag client)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Gelato$2f$72$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/public/menu/Gelato/72.jpeg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Gelato$2f$72$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1800,
    height: 900,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAEAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDmodSuZLvynYFUlDDjHbGPpzXBypK53czc9T//2Q=="
};
}),
"[project]/O2-Gaza-Project/app/categories/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CategoriesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$navbar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/navbar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$footer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/footer.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$branch$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/branch-context.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$menu$2d$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/menu-data.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Shawarma$2f$18$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Shawarma$2f$18$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Shawarma/18.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Shawarma/18.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Italian$2f$35$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Italian$2f$35$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Italian/35.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Italian/35.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Western$2f$43$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Western$2f$43$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Western/43.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Western/43.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Sweets$2f$27$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Sweets$2f$27$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Sweets/27.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Sweets/27.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Bar$2f$16$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Bar$2f$16$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Bar/16.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Bar/16.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Cake$2f$11$2e$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Cake$2f$11$2e$2$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Cake/11.2.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Cake/11.2.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$drinks$2f$13$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$drinks$2f$13$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/drinks/13.jpg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/drinks/13.jpg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$salad$2f$20$2e$jpeg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$salad$2f$20$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/salad/20.jpeg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/salad/20.jpeg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Gelato$2f$72$2e$jpeg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Gelato$2f$72$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/O2-Gaza-Project/public/menu/Gelato/72.jpeg.mjs { IMAGE => "[project]/O2-Gaza-Project/public/menu/Gelato/72.jpeg (static in ecmascript, tag client)" } [app-ssr] (structured image object with data url, ecmascript)');
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const CATEGORY_DISPLAY = [
    {
        id: "shawarma",
        name: "الشاورما",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Shawarma$2f$18$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Shawarma$2f$18$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🌯"
    },
    {
        id: "italian",
        name: "الإيطالي",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Italian$2f$35$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Italian$2f$35$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🍕"
    },
    {
        id: "sandwiches",
        name: "السندويشات",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Western$2f$43$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Western$2f$43$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🥪"
    },
    {
        id: "easternSweets",
        name: "الحلويات الشرقية",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Sweets$2f$27$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Sweets$2f$27$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🍰"
    },
    {
        id: "westernSweets",
        name: "الكيك والحلويات",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Cake$2f$11$2e$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Cake$2f$11$2e$2$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🎂"
    },
    {
        id: "barSweets",
        name: "حلويات البار",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Bar$2f$16$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Bar$2f$16$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🍫"
    },
    {
        id: "drinks",
        name: "المشروبات",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$drinks$2f$13$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$drinks$2f$13$2e$jpg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🥤"
    },
    {
        id: "salads",
        name: "السلطات",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$salad$2f$20$2e$jpeg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$salad$2f$20$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🥗"
    },
    {
        id: "gelato",
        name: "الجيلاتو",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Gelato$2f$72$2e$jpeg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$O2$2d$Gaza$2d$Project$2f$public$2f$menu$2f$Gelato$2f$72$2e$jpeg__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        emoji: "🍰"
    }
];
function CategoriesPage() {
    const { selectedBranch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$branch$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useBranch"])();
    const branchMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$menu$2d$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getMenuByBranch"])(selectedBranch || "gaza");
    const [isPaused, setIsPaused] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dimensions, setDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        radius: 210,
        itemSize: 110
    });
    const categories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>CATEGORY_DISPLAY.filter((c)=>branchMenu[c.id]), [
        branchMenu
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const update = ()=>{
            const w = window.innerWidth;
            if (w < 480) setDimensions({
                radius: 140,
                itemSize: 75
            });
            else if (w < 768) setDimensions({
                radius: 180,
                itemSize: 90
            });
            else if (w < 1024) setDimensions({
                radius: 220,
                itemSize: 100
            });
            else setDimensions({
                radius: 260,
                itemSize: 110
            });
        };
        update();
        window.addEventListener("resize", update);
        return ()=>window.removeEventListener("resize", update);
    }, []);
    if (!categories.length) return null;
    const { radius, itemSize } = dimensions;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-background overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$navbar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Navbar"], {}, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "pt-28 pb-10 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/select-branch",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].button, {
                            whileHover: {
                                scale: 1.02
                            },
                            whileTap: {
                                scale: 0.98
                            },
                            className: "mb-6 inline-flex items-center gap-2 rounded-lg cursor-pointer bg-primary px-5 py-2.5 font-semibold text-primary-foreground  hover:bg-primary/90 transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                    lineNumber: 98,
                                    columnNumber: 13
                                }, this),
                                "اختر فرع آخر"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold",
                        children: "استكشف الأقسام"
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-muted-foreground",
                        children: selectedBranch === "middle" ? "فرع الوسطى" : "فرع غزة"
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative flex items-center justify-center h-[520px] pb-10 mt-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "relative z-10",
                        style: {
                            width: radius * 2 + 140,
                            height: radius * 2 + 140
                        },
                        animate: isPaused ? {} : {
                            rotate: 360
                        },
                        transition: {
                            duration: 40,
                            repeat: Infinity,
                            ease: "linear"
                        },
                        onMouseEnter: ()=>setIsPaused(true),
                        onMouseLeave: ()=>setIsPaused(false),
                        children: categories.map((cat, i)=>{
                            const angle = i / categories.length * 2 * Math.PI - Math.PI / 2;
                            const x = Math.cos(angle) * radius;
                            const y = Math.sin(angle) * radius;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                className: "absolute",
                                style: {
                                    left: `calc(50% + ${x}px)`,
                                    top: `calc(50% + ${y}px)`,
                                    width: itemSize,
                                    height: itemSize,
                                    transform: "translate(-50%, -50%)"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/category/${cat.id}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                        className: "relative w-full h-full rounded-full overflow-hidden border-2 border-primary shadow-lg hover:scale-110 transition bg-card",
                                        animate: isPaused ? {} : {
                                            rotate: -360
                                        },
                                        transition: {
                                            duration: 40,
                                            repeat: Infinity,
                                            ease: "linear"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                src: cat.image,
                                                alt: cat.name,
                                                fill: true,
                                                className: "object-cover"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                                lineNumber: 147,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute inset-0 bg-black/60 flex items-end justify-center p-2",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white text-[10px] sm:text-xs font-bold text-center",
                                                    children: cat.name
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                                    lineNumber: 154,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                                lineNumber: 153,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                        lineNumber: 138,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                    lineNumber: 136,
                                    columnNumber: 17
                                }, this)
                            }, cat.id, false, {
                                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                lineNumber: 125,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary text-white flex flex-col items-center justify-center font-extrabold shadow-2xl z-20 pointer-events-none",
                        style: {
                            width: itemSize * 1.2,
                            height: itemSize * 1.2,
                            maxWidth: "160px",
                            maxHeight: "160px"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-2xl sm:text-4xl",
                                children: "🍽️"
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                lineNumber: 175,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm sm:text-xl mt-1",
                                children: "الأقسام"
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                                lineNumber: 176,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$footer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Footer"], {}, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
                lineNumber: 180,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/O2-Gaza-Project/app/categories/page.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=O2-Gaza-Project_c4b9f195._.js.map