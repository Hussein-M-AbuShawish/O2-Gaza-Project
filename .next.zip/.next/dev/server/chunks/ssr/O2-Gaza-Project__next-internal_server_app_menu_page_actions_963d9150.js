module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/menu/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_menu_page_actions_963d9150.js.map