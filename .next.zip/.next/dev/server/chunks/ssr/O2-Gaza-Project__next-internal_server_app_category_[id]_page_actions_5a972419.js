module.exports = [
"[project]/O2-Gaza-Project/.next-internal/server/app/category/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=O2-Gaza-Project__next-internal_server_app_category_%5Bid%5D_page_actions_5a972419.js.map