(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/O2-Gaza-Project_b32bb804._.js",
  "static/chunks/5f8e7_motion-dom_dist_es_bd0553e6._.js",
  "static/chunks/5f8e7_framer-motion_dist_es_d7253b09._.js",
  "static/chunks/5f8e7_tailwind-merge_dist_bundle-mjs_mjs_87444dfd._.js",
  "static/chunks/5f8e7_next_8a232ace._.js",
  "static/chunks/5f8e7_bfa11612._.js"
],
    source: "dynamic"
});
