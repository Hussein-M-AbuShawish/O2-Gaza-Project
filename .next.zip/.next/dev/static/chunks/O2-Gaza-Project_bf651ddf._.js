(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/O2-Gaza-Project/node_modules/react-leaflet/lib/index.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/5f8e7_5377fb15._.js",
  "static/chunks/5f8e7_react-leaflet_lib_index_8bf808c6.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/O2-Gaza-Project/node_modules/react-leaflet/lib/index.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/O2-Gaza-Project/components/Map.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/5f8e7_ccb46f19._.js",
  "static/chunks/O2-Gaza-Project_components_Map_tsx_bfc3e923._.js",
  "static/chunks/O2-Gaza-Project_components_Map_tsx_46148590._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/O2-Gaza-Project/components/Map.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);