(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f6adda86._.js",
  "static/chunks/5f8e7_next_dist_compiled_react-dom_0a3aa0e5._.js",
  "static/chunks/5f8e7_next_dist_compiled_react-server-dom-turbopack_38f86528._.js",
  "static/chunks/5f8e7_next_dist_compiled_next-devtools_index_f4b8696c.js",
  "static/chunks/5f8e7_next_dist_compiled_0a31062c._.js",
  "static/chunks/5f8e7_next_dist_client_d222f18b._.js",
  "static/chunks/5f8e7_next_dist_721ad10b._.js",
  "static/chunks/5f8e7_@swc_helpers_cjs_33069d6b._.js"
],
    source: "entry"
});
