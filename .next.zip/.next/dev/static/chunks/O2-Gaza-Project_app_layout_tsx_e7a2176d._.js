(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__088e9657._.css",
  "static/chunks/O2-Gaza-Project_d332af92._.js"
],
    source: "dynamic"
});
