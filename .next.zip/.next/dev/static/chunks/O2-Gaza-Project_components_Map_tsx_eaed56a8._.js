(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/5f8e7__pnpm_6a17cfad._.js",
  "static/chunks/O2-Gaza-Project_components_Map_tsx_bfc3e923._.js"
],
    source: "dynamic"
});
