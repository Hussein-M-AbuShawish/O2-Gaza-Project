(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/O2-Gaza-Project_4de3eeb9._.js",
  "static/chunks/O2-Gaza-Project_0ef2182d._.js",
  "static/chunks/7d4fa_motion-dom_dist_es_0c50409a._.js",
  "static/chunks/a8cf7_framer-motion_dist_es_4d8a626c._.js",
  "static/chunks/6371a_tailwind-merge_dist_bundle-mjs_mjs_b84f4b6a._.js",
  "static/chunks/05afb_next_7719f3f0._.js",
  "static/chunks/5f8e7__pnpm_9ece90d4._.js",
  "static/chunks/8d286_leaflet_dist_leaflet_37624d8f.css"
],
    source: "dynamic"
});
