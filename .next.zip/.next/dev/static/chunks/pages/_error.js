__turbopack_load_page_chunks__("/_error", [
  "static/chunks/05afb_next_dist_compiled_d29b159d._.js",
  "static/chunks/05afb_next_dist_shared_lib_abd86731._.js",
  "static/chunks/05afb_next_dist_client_2b2f9e85._.js",
  "static/chunks/05afb_next_dist_bdda5f3a._.js",
  "static/chunks/05afb_next_error_f617ecef.js",
  "static/chunks/[next]_entry_page-loader_ts_f8fb7f3c._.js",
  "static/chunks/3a3fc_react-dom_5a35c5bc._.js",
  "static/chunks/5f8e7__pnpm_74297f42._.js",
  "static/chunks/[root-of-the-server]__0146f2fa._.js",
  "static/chunks/O2-Gaza-Project_pages__error_2da965e7._.js",
  "static/chunks/turbopack-O2-Gaza-Project_pages__error_06f5d275._.js"
])
