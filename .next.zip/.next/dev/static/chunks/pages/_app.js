__turbopack_load_page_chunks__("/_app", [
  "static/chunks/05afb_next_dist_compiled_d29b159d._.js",
  "static/chunks/05afb_next_dist_shared_lib_3d923b5b._.js",
  "static/chunks/05afb_next_dist_client_2b2f9e85._.js",
  "static/chunks/05afb_next_dist_65c92632._.js",
  "static/chunks/05afb_next_app_3ca07c8e.js",
  "static/chunks/[next]_entry_page-loader_ts_be17f92c._.js",
  "static/chunks/3a3fc_react-dom_5a35c5bc._.js",
  "static/chunks/5f8e7__pnpm_74297f42._.js",
  "static/chunks/[root-of-the-server]__a805afcd._.js",
  "static/chunks/O2-Gaza-Project_pages__app_2da965e7._.js",
  "static/chunks/turbopack-O2-Gaza-Project_pages__app_11f25d4b._.js"
])
