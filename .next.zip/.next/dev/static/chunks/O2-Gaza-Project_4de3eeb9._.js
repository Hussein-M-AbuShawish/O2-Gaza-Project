(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/O2-Gaza-Project/node_modules/.pnpm/react-leaflet@5.0.0_leaflet_80817c3ec6eef31a52c50cfc2b454618/node_modules/react-leaflet/lib/index.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/5f8e7__pnpm_ba5390c2._.js",
  "static/chunks/965ed_react-leaflet_lib_index_b41c7e6f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/O2-Gaza-Project/node_modules/.pnpm/react-leaflet@5.0.0_leaflet_80817c3ec6eef31a52c50cfc2b454618/node_modules/react-leaflet/lib/index.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/O2-Gaza-Project/components/Map.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/5f8e7__pnpm_6a17cfad._.js",
  "static/chunks/O2-Gaza-Project_components_Map_tsx_bfc3e923._.js",
  "static/chunks/O2-Gaza-Project_components_Map_tsx_eaed56a8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/O2-Gaza-Project/components/Map.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);