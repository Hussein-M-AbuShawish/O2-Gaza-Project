(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/O2-Gaza-Project_1774debc._.js",
  "static/chunks/5f8e7_44a841ae._.js"
],
    source: "dynamic"
});
