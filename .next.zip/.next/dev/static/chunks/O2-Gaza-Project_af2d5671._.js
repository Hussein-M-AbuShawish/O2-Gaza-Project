(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/O2-Gaza-Project/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$3$2e$1$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/tailwind-merge@3.3.1/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$3$2e$1$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/O2-Gaza-Project/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$1$2e$1_$40$types$2b$react$40$19$2e$0$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/@radix-ui+react-slot@1.1.1_@types+react@19.0.0_react@19.2.0/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: 'bg-primary text-primary-foreground hover:bg-primary/90',
            destructive: 'bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
            outline: 'border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50',
            secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
            ghost: 'hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50',
            link: 'text-primary underline-offset-4 hover:underline'
        },
        size: {
            default: 'h-9 px-4 py-2 has-[>svg]:px-3',
            sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5',
            lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
            icon: 'size-9',
            'icon-sm': 'size-8',
            'icon-lg': 'size-10'
        }
    },
    defaultVariants: {
        variant: 'default',
        size: 'default'
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$1$2e$1_$40$types$2b$react$40$19$2e$0$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/components/ui/button.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/O2-Gaza-Project/components/product-card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCard",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/framer-motion@12.27.0_@emot_ea24378ea94ca90bc41379238f9f0cd6/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/image.js [app-client] (ecmascript)");
"use client";
;
;
;
function ProductCard({ item, index, onClick, byWeight }) {
    const getDisplayPrice = ()=>{
        if (item.pricePerKg) return `${item.pricePerKg} ₪/كغ`;
        if (item.variants && item.variants.length > 0) {
            const minPrice = Math.min(...item.variants.map((v)=>v.price));
            return `تبدأ من ${minPrice} ₪`;
        }
        return `${item.price} ₪`;
    };
    const displayPrice = getDisplayPrice();
    const isUnavailable = item.delivery === false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0,
            y: 20
        },
        whileInView: {
            opacity: 1,
            y: 0
        },
        viewport: {
            once: true,
            margin: "-50px"
        },
        transition: {
            duration: 0.4,
            delay: index * 0.05
        },
        onClick: onClick,
        className: `group relative bg-card rounded-lg ${item.active ? "" : "hidden"} overflow-hidden aspect-[3/4] cursor-pointer transition-all duration-300 ${isUnavailable ? "opacity-60" : "hover:shadow-md active:scale-[0.98]"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full h-2/3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: item.image || "/placeholder.svg",
                    alt: item.name,
                    fill: true,
                    className: `object-cover transition-transform duration-300 ${!isUnavailable && "group-hover:scale-105"}`,
                    sizes: "(max-width: 500px) 50vw, (max-width: 768px) 33vw, 25vw"
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 md:p-4 h-1/3 flex flex-col justify-between bg-card",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-sm md:text-base font-semibold text-foreground leading-tight line-clamp-2",
                        children: item.name
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between pt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-primary font-bold text-sm md:text-base",
                                children: displayPrice
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this),
                            isUnavailable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-muted-foreground font-medium",
                                children: "غير متاح"
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                                lineNumber: 80,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/O2-Gaza-Project/components/product-card.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/O2-Gaza-Project/components/navbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Navbar",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/framer-motion@12.27.0_@emot_ea24378ea94ca90bc41379238f9f0cd6/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/framer-motion@12.27.0_@emot_ea24378ea94ca90bc41379238f9f0cd6/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const navLinks = [
    {
        href: "/about",
        label: "من نحن"
    },
    {
        href: "/#services",
        label: "أنشطتنا"
    },
    {
        href: "/select-branch",
        label: "اطلب الان"
    },
    {
        href: "/#reviews",
        label: "آراء العملاء"
    },
    {
        href: "/#contact",
        label: "تواصل معنا"
    }
];
function Navbar() {
    _s();
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            const handleScroll = {
                "Navbar.useEffect.handleScroll": ()=>{
                    setIsScrolled(window.scrollY > 50);
                }
            }["Navbar.useEffect.handleScroll"];
            window.addEventListener("scroll", handleScroll);
            return ({
                "Navbar.useEffect": ()=>window.removeEventListener("scroll", handleScroll)
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].nav, {
                initial: {
                    y: -100
                },
                animate: {
                    y: 0
                },
                transition: {
                    duration: 0.5
                },
                className: `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? "bg-background/80 backdrop-blur-lg border-b border-border/50 shadow-lg" : "bg-transparent"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between h-16 md:h-20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "flex items-center gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-3xl md:text-4xl font-bold",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-foreground",
                                            children: "Gaza"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 45,
                                            columnNumber: 17
                                        }, this),
                                        " ",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "o2-logo-red text-primary",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "2"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 19
                                                }, this),
                                                "0"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 46,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 44,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden lg:flex items-center gap-1",
                                children: navLinks.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: link.href,
                                        className: "px-4 py-2 text-muted-foreground hover:text-foreground transition-colors text-sm font-medium",
                                        children: link.label
                                    }, link.href, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 55,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden lg:block",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    asChild: true,
                                    className: "bg-primary text-primary-foreground hover:bg-primary/90",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/select-branch",
                                        target: "_blank",
                                        children: "اطلب الآن"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 71,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 67,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "lg:hidden p-2 text-foreground",
                                onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                                "aria-label": isMobileMenuOpen ? "إغلاق القائمة" : "فتح القائمة",
                                children: isMobileMenuOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 24
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 87,
                                    columnNumber: 35
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                    size: 24
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 87,
                                    columnNumber: 53
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                lineNumber: 81,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        y: -20
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    exit: {
                        opacity: 0,
                        y: -20
                    },
                    transition: {
                        duration: 0.2
                    },
                    className: "fixed inset-0 z-40 lg:hidden",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0 bg-background/95 backdrop-blur-lg",
                            onClick: ()=>setIsMobileMenuOpen(false),
                            onKeyDown: (e)=>e.key === "Escape" && setIsMobileMenuOpen(false)
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                            lineNumber: 103,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            transition: {
                                delay: 0.1
                            },
                            className: "relative pt-24 px-6 flex flex-col gap-4",
                            children: [
                                navLinks.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                        initial: {
                                            opacity: 0,
                                            x: -20
                                        },
                                        animate: {
                                            opacity: 1,
                                            x: 0
                                        },
                                        transition: {
                                            delay: index * 0.05
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: link.href,
                                            className: "block py-3 text-xl text-foreground hover:text-primary transition-colors border-b border-border/50",
                                            onClick: ()=>setIsMobileMenuOpen(false),
                                            children: link.label
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 123,
                                            columnNumber: 19
                                        }, this)
                                    }, link.href, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 117,
                                        columnNumber: 17
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    initial: {
                                        opacity: 0,
                                        x: -20
                                    },
                                    animate: {
                                        opacity: 1,
                                        x: 0
                                    },
                                    transition: {
                                        delay: navLinks.length * 0.05
                                    },
                                    className: "mt-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        asChild: true,
                                        className: "w-full bg-primary text-primary-foreground hover:bg-primary/90",
                                        size: "lg",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/select-branch",
                                            target: "_blank",
                                            children: "اطلب الآن"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                            lineNumber: 143,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                            lineNumber: 110,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                    lineNumber: 96,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/components/navbar.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Navbar, "0+zEKVBL95ILuBb5rHE6ViYOHu8=");
_c = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/O2-Gaza-Project/components/footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Footer",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/framer-motion@12.27.0_@emot_ea24378ea94ca90bc41379238f9f0cd6/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/facebook.js [app-client] (ecmascript) <export default as Facebook>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/instagram.js [app-client] (ecmascript) <export default as Instagram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/twitter.js [app-client] (ecmascript) <export default as Twitter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$youtube$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Youtube$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/youtube.js [app-client] (ecmascript) <export default as Youtube>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
"use client";
;
;
;
;
const quickLinks = [
    {
        href: "/about",
        label: "من نحن"
    },
    {
        href: "/services",
        label: "خدماتنا"
    },
    {
        href: "/categories",
        label: "قائمتنا"
    },
    {
        href: "#contact",
        label: "تواصل معنا"
    }
];
const socialLinks = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__["Facebook"],
        href: "#",
        label: "فيسبوك"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__["Instagram"],
        href: "#",
        label: "إنستغرام"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__["Twitter"],
        href: "#",
        label: "تويتر"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$youtube$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Youtube$3e$__["Youtube"],
        href: "#",
        label: "يوتيوب"
    }
];
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-card border-t border-border/50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 py-12 md:py-16",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 items-start",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5
                            },
                            viewport: {
                                once: true
                            },
                            className: "lg:col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "inline-block mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-3xl font-bold",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-foreground",
                                                children: "Gaza"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 45,
                                                columnNumber: 17
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "o2-logo-red text-primary",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                        lineNumber: 47,
                                                        columnNumber: 19
                                                    }, this),
                                                    "0"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 46,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                        lineNumber: 44,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-muted-foreground leading-relaxed mb-6",
                                    children: "تجربة طعام استثنائية تجمع بين الأصالة والحداثة، حيث نقدم لكم أشهى المأكولات في أجواء راقية."
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-3",
                                    children: socialLinks.map((social)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: social.href,
                                            "aria-label": social.label,
                                            className: "w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(social.icon, {
                                                className: "w-5 h-5"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 64,
                                                columnNumber: 19
                                            }, this)
                                        }, social.label, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 58,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.1
                            },
                            viewport: {
                                once: true
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-foreground mb-4",
                                    children: "روابط سريعة"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3",
                                    children: quickLinks.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: link.href,
                                                className: "text-muted-foreground hover:text-primary transition-colors",
                                                children: link.label
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 83,
                                                columnNumber: 19
                                            }, this)
                                        }, link.href, false, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.2
                            },
                            viewport: {
                                once: true
                            },
                            className: "lg:col-span-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-foreground mb-4",
                                    children: "فروعنا"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-6 flex justify-between md:justify-start lg:justify-normal",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "lg:col-span-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold mb-4 text-primary",
                                                    children: "فرع غزة"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 104,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                    className: "space-y-3 text-sm text-muted-foreground",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 107,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " مدينة غزة، شارع النصر"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 106,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            dir: "rtl",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 110,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    dir: "ltr",
                                                                    children: "+972 59 711 1811"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 111,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 109,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 114,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " info@o2gaza.com"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 113,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 105,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 103,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "lg:col-span-1 lg:ms-20 :ml-30 xl:ms-32 transition-all",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold mb-4 text-primary",
                                                    children: "فرع النصيرات"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 120,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                    className: "space-y-3 text-sm text-muted-foreground",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 125,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " النصيرات، مفترق ابو صرار"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 124,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            dir: "rtl",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 128,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    dir: "ltr",
                                                                    children: "+972 59 711 1811"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 129,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 127,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                                    lineNumber: 132,
                                                                    columnNumber: 21
                                                                }, this),
                                                                " info@o2gaza.com"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                            lineNumber: 131,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                    lineNumber: 123,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                            lineNumber: 119,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 102,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 94,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.3
                            },
                            viewport: {
                                once: true
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-foreground mb-4",
                                    children: "ساعات العمل"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3 text-muted-foreground",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "جميع أيام الاسبوع"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 151,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "10:00 ص - 10:00 م"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                                lineNumber: 152,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                            lineNumber: 140,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0
                    },
                    whileInView: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.5,
                        delay: 0.4
                    },
                    viewport: {
                        once: true
                    },
                    className: "mt-12 pt-8 border-t border-border/50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row justify-between items-center gap-4 text-muted-foreground text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "جميع الحقوق محفوظة © ",
                                    new Date().getFullYear(),
                                    " مطعم O2 Gaza"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                lineNumber: 167,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "تم تطويره بواسطة فريق 02 المميز"
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                                lineNumber: 170,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                        lineNumber: 166,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
                    lineNumber: 159,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
            lineNumber: 32,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/components/footer.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_c = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/O2-Gaza-Project/lib/menu-data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Branch-specific menu data
// Each branch has its own independent menu with all categories
__turbopack_context__.s([
    "branchMenuData",
    ()=>branchMenuData,
    "categoryNames",
    ()=>categoryNames,
    "getCategoryByBranch",
    ()=>getCategoryByBranch,
    "getMenuByBranch",
    ()=>getMenuByBranch
]);
const categoryNames = {
    shawarma: "الشاورما",
    italian: "الإيطالي",
    sandwiches: "السندويشات الغربية",
    easternSweets: "الحلويات الشرقية",
    westernSweets: "الكيك والحلويات الغربية",
    barSweets: "حلويات البار",
    drinks: "المشروبات",
    salads: "السلطات",
    gelato: "الجيلاتو"
};
// Helper to apply default value for active
function withDefaultActive(items) {
    return items.map((item)=>({
            ...item,
            active: item.active ?? true
        }));
}
// Gaza Branch Menu
const gazaMenu = {
    shawarma: {
        title: "الشاورما",
        items: withDefaultActive([
            {
                name: "بيتا شاورما",
                price: 10,
                image: "/menu/shawarma/54.jpg"
            },
            {
                name: "شاورما عادي",
                price: 15,
                image: "/menu/shawarma/48.jpg",
                active: true
            },
            {
                name: "فرشوحه دبل",
                price: 17,
                image: "/menu/shawarma/49.jpg"
            },
            {
                name: "فرشوحه دبل لحمة",
                price: 23,
                image: "/menu/shawarma/48.jpg"
            },
            {
                name: "فرشوحه دبل دبل",
                price: 25,
                image: "/menu/shawarma/48.jpg",
                delivery: false
            },
            {
                name: "سوري",
                price: 28,
                image: "/menu/shawarma/53.jpg"
            },
            {
                name: "صفيحة",
                price: 30,
                desc: "شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/51.jpg"
            },
            {
                name: "باشكا",
                price: 40,
                desc: "خبزة باشكا - شاورما - جبنة - زيتون - صوص بيكانتي",
                image: "/menu/shawarma/18.jpg"
            },
            {
                name: "شاورما عربي",
                price: 30,
                desc: "قطع شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/17.jpg"
            },
            {
                name: "شاورما نابلسي",
                price: 30,
                desc: "شاورما - بطاطا - صوص بيكانتي - جبنة - زيتون اسود",
                image: "/menu/shawarma/19.jpg"
            },
            {
                name: "صحن شاورما",
                price: 30,
                image: "/menu/shawarma/14.jpg"
            },
            {
                name: "صحن شاورما",
                price: 20,
                image: "/menu/shawarma/13.jpg"
            }
        ])
    },
    italian: {
        title: "الإيطالي",
        items: withDefaultActive([
            {
                name: "كاليزوني دجاج",
                price: 30,
                desc: "صدر دجاج - جبنة - زيتون - رانش",
                image: "/menu/italian/35.jpg"
            },
            {
                name: "كاليزوني خضار",
                price: 15,
                desc: "فليفلة - بصل - ذرة - مشروم - زيتون",
                image: "/menu/italian/36.jpg"
            },
            {
                name: "بيتزا مكسيكي دجاج",
                price: 20,
                desc: "صدر دجاج - جبنة - زيتون",
                image: "/menu/italian/33.jpg"
            },
            {
                name: "ميجا",
                price: 30,
                desc: "صدر دجاج - فليفلة - مشروم - جرادة - بصل - كريمة طعام",
                image: "/menu/italian/34.jpg"
            },
            {
                name: "بيتزا خضار",
                price: 15,
                desc: "خضار - ذرة - زيتون",
                image: "/menu/italian/32.jpg"
            },
            {
                name: "بيتزا ماما روزا بالاناناس",
                price: 15,
                desc: "أناناس",
                image: "/menu/italian/2.jpg"
            },
            {
                name: "نابولي",
                price: 15,
                desc: "بيتزا بالتونة والزيتون",
                image: "/menu/italian/3.jpg"
            },
            {
                name: "مارجريتا",
                price: 15,
                desc: "جبنة",
                image: "/menu/italian/1.jpg"
            },
            {
                name: "صوص رانش",
                price: 3,
                image: "/menu/italian/7.jpeg"
            }
        ])
    },
    sandwiches: {
        title: "السندويشات الغربية",
        items: withDefaultActive([
            {
                name: "زينجر",
                price: 25,
                desc: "شرائح صدر دجاج متبّلة مع بندورة طازجة، جرجير، حلقات بصل",
                image: "/menu/western/44.jpg"
            },
            {
                name: "بيف برجر",
                price: 25,
                desc: "قطعة لحمة - بصل - بندورة - جبنة - مخلل - صوص بيكانتي",
                image: "/menu/western/40.jpg"
            },
            {
                name: "بيغ ماك",
                price: 35,
                desc: "قطعتين لحمة - بصل - بندورة - جبنة - مخلل - صوص بيكانتي",
                image: "/menu/western/46.jpg"
            },
            {
                name: "تشكن بيتزا",
                price: 25,
                desc: "صدر دجاج - مشروم - فليفلة - بصل - زيتون اسود - جبنة",
                image: "/menu/western/45.jpg"
            },
            {
                name: "شيش طاووق",
                price: 25,
                desc: "فخد دجاج - جرجير - بندورة -مخلل -صوص بيكانتي",
                image: "/menu/western/47.jpg"
            },
            {
                name: "فطيرة الذهبية",
                price: 25,
                desc: "صدر دجاج - فليفلة - بصل - زيتون اسود - جبنة - ذرة - كريمة طعام",
                image: "/menu/western/43.jpg"
            }
        ])
    },
    easternSweets: {
        title: "الحلويات الشرقية",
        byWeight: true,
        items: withDefaultActive([
            {
                name: "نمورة",
                pricePerKg: 15,
                image: "/menu/sweets/25.jpeg"
            },
            {
                name: "بسبوسة",
                pricePerKg: 20,
                image: "/menu/sweets/82.jpeg"
            },
            {
                name: "كلاج",
                pricePerKg: 20,
                image: "/menu/sweets/3.1.jpg"
            },
            {
                name: "عش البلبل",
                pricePerKg: 30,
                image: "/menu/sweets/7.jpg"
            },
            {
                name: "نابلسية",
                pricePerKg: 60,
                image: "/menu/sweets/23.jpg"
            },
            {
                name: "كنافة عربية",
                pricePerKg: 40,
                image: "/menu/sweets/11.jpg"
            },
            {
                name: "معكوفة لوز",
                pricePerKg: 35,
                image: "/menu/sweets/6.jpg"
            },
            {
                name: "كول واشكر",
                pricePerKg: 30,
                image: "/menu/sweets/5.jpg"
            },
            {
                name: "سنيورة",
                pricePerKg: 30,
                image: "/menu/sweets/8.jpg"
            },
            {
                name: "سرة",
                pricePerKg: 35,
                image: "/menu/sweets/2.jpg"
            },
            {
                name: "وربات",
                pricePerKg: 35,
                image: "/menu/sweets/2.jpg"
            },
            {
                name: "معكوفة عين جمل",
                pricePerKg: 35,
                image: "/menu/sweets/26.jpg"
            },
            {
                name: "بسبوسة نوتيلا",
                pricePerKg: 40,
                image: "/menu/sweets/18.jpeg"
            },
            {
                name: "بقلاوة عين جمل",
                pricePerKg: 55,
                image: "/menu/sweets/41.jpg"
            },
            {
                name: "بقلاوة لوز",
                pricePerKg: 48,
                image: "/menu/sweets/9.jpg"
            },
            {
                name: "بقلاوة حلبي",
                pricePerKg: 100,
                image: "/menu/sweets/10.jpg"
            },
            {
                name: "أساور لوز",
                pricePerKg: 48,
                image: "/menu/sweets/19.jpeg"
            },
            {
                name: "كاسات مكسرات",
                pricePerKg: 80,
                image: "/menu/sweets/24.jpg"
            },
            {
                name: "بورما حلبي",
                pricePerKg: 100,
                image: "/menu/sweets/78.jpeg"
            },
            {
                name: "بلورية حلبي",
                pricePerKg: 130,
                image: "/menu/sweets/84.jpeg"
            },
            {
                name: "دولمة حلبي",
                pricePerKg: 130,
                image: "/menu/sweets/27.jpg"
            }
        ])
    },
    westernSweets: {
        title: "الكيك والحلويات الغربية",
        items: withDefaultActive([
            {
                name: "قالب كيك صغير",
                price: 60,
                image: "/menu/cake/9.jpg"
            },
            {
                name: "قالب كيك كبير",
                price: 80,
                image: "/menu/cake/10.jpg"
            },
            {
                name: "قالب كيك اسبيسشل صغير",
                price: 80,
                image: "/menu/cake/38.jpg"
            },
            {
                name: "قالب كيك اسبيسشل كبير",
                price: 100,
                image: "/menu/cake/88.jpeg"
            },
            {
                name: "سويس رول",
                price: 8,
                image: "/menu/cake/31.jpg"
            },
            {
                name: "تريلتشا",
                price: 10,
                image: "/menu/cake/21.jpg"
            },
            {
                name: "قطع كيك كلاسيكي",
                price: 5,
                image: "/menu/cake/5.jpg"
            },
            {
                name: "قطع كيك سبيشل",
                price: 10,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/cake/30.jpg"
            },
            {
                name: "سوبريم",
                price: 18,
                desc: "لوتس - نوتيلا - بيستاشيو",
                image: "/menu/cake/28.jpg"
            },
            {
                name: "موس",
                price: 15,
                desc: "كيندر- لوتس - نوتيلا - بيستاشيو",
                image: "/menu/cake/4.jpg"
            },
            {
                name: "تشيس كيك",
                price: 15,
                image: "/menu/cake/7.jpg"
            },
            {
                name: "كرانش بار",
                price: 15,
                image: "/menu/cake/23.jpg"
            },
            {
                name: "قالب نص بلاطة",
                price: 150,
                image: "/menu/cake/8.1.jpg"
            }
        ])
    },
    barSweets: {
        title: "حلويات البار",
        items: withDefaultActive([
            {
                name: "كريب شوكولاتة",
                price: 15,
                image: "/menu/bar/16.jpg",
                active: false
            },
            {
                name: "كريب (نوتيلا / بيستاشيو / لوتس)",
                price: 25,
                image: "/menu/bar/64.jpg"
            },
            {
                name: "كريب دبي",
                price: 30,
                image: "/menu/bar/14.jpg"
            },
            {
                name: "بان كيك",
                price: 25,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/bar/67.jpeg"
            },
            {
                name: "ميني بان كيك",
                price: 25,
                image: "/menu/bar/13.jpg",
                desc: "نوتيلا / بيستاشيو / لوتس"
            },
            {
                name: "رينجز",
                price: 25,
                image: "/menu/bar/56.jpg"
            },
            {
                name: "لقيمات شوكولاتة",
                price: 15,
                image: "/menu/bar/15.jpg",
                active: false
            },
            {
                name: "لقيمات (نوتيلا / بيستاشيو / لوتس)",
                price: 25,
                image: "/menu/bar/55.jpg"
            },
            {
                name: "بان كيك شوكولاتة",
                price: 15,
                image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800&q=80",
                active: false
            },
            {
                name: "مولتن كيك",
                price: 20,
                image: "/menu/bar/37.jpg"
            },
            {
                name: "هوت كيك",
                price: 20,
                image: "/menu/bar/38.jpg"
            },
            {
                name: "براونيز",
                price: 20,
                image: "/menu/bar/59.jpg"
            },
            {
                name: "تاياكي",
                price: 25,
                image: "/menu/bar/38.jpg"
            },
            {
                name: "ميني فيشز",
                price: 25,
                image: "/menu/bar/68.jpeg",
                desc: "نوتيلا / بيستاشيو / لوتس"
            },
            {
                name: "وافل ستيك",
                price: 25,
                image: "/menu/bar/85.jpeg",
                desc: "نوتيلا / بيستاشيو / لوتس"
            },
            {
                name: "كنافة نويتلا",
                price: 15,
                image: "/menu/bar/58.jpg"
            }
        ])
    },
    gelato: {
        title: "الجيلاتو",
        items: withDefaultActive([
            {
                name: "جيلاتو نوتيلا",
                price: 15,
                image: "/menu/Gelato/70.jpeg"
            },
            {
                name: "جيلاتو بستاشيو",
                price: 15,
                image: "/menu/Gelato/72.jpeg"
            },
            {
                name: "جيلاتو لوتس",
                price: 15,
                image: "/menu/Gelato/70.jpeg"
            },
            {
                name: "جيلاتو كيندر",
                price: 15,
                image: "/menu/Gelato/70.jpeg"
            },
            {
                name: "جيلاتو بلوبيري",
                price: 15,
                image: "/menu/Gelato/79.jpeg"
            },
            {
                name: "جيلاتو عربية",
                price: 15,
                image: "/menu/Gelato/75.jpeg"
            }
        ])
    },
    drinks: {
        title: "المشروبات",
        items: withDefaultActive([
            {
                name: "عصير الموسم",
                price: 10,
                image: "/menu/drinks/1.jpg"
            },
            {
                name: "عصير أناناس",
                price: 10,
                image: "/menu/drinks/2.jpg"
            },
            {
                name: "ليمون ونعنع",
                price: 10,
                image: "/menu/drinks/3.jpg"
            },
            {
                name: "أفوكادو",
                price: 15,
                image: "/menu/drinks/4.jpg"
            },
            {
                name: "شوكو بارد",
                price: 10,
                image: "/menu/drinks/7.jpg"
            },
            {
                name: "ايس موكا",
                price: 10,
                image: "/menu/drinks/5.jpg"
            },
            {
                name: "آيس كافي",
                price: 10,
                image: "/menu/drinks/10.jpg"
            },
            {
                name: "ميلك شيك",
                price: 15,
                image: "/menu/drinks/8.jpg",
                desc: "شوكولاتة / فانيلا / فراولة / اوريو / بلوبيري"
            },
            {
                name: "موهيتو",
                price: 20,
                image: "/menu/drinks/16.jpg"
            },
            {
                name: "نسكافيه",
                price: 5,
                image: "/menu/drinks/9.jpg"
            },
            {
                name: "كابتشينو",
                price: 5,
                image: "/menu/drinks/9.jpg"
            },
            {
                name: "اسبريسو سينجل",
                price: 5,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: "اسبريسو دبل",
                price: 10,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: " قهوة تركي سينجل",
                price: 5,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: "قهوة تركي دبل",
                price: 10,
                image: "/menu/drinks/6.jpg"
            },
            {
                name: "شاي",
                price: 3,
                image: "/menu/drinks/11.jpg"
            },
            {
                name: "بلو",
                price: 4,
                image: "/menu/drinks/17.jpg"
            },
            {
                name: "كوكا كولا",
                price: 5,
                image: "/menu/drinks/18.jpg"
            },
            {
                name: "سبرايت",
                price: 5,
                image: "/menu/drinks/19.jpg"
            },
            {
                name: "مياه معدنية 200 ملم",
                price: 1,
                image: "/menu/drinks/12.jpg"
            },
            {
                name: "مياه معدنية 500 ملم",
                price: 2,
                image: "/menu/drinks/13.jpg"
            }
        ])
    },
    salads: {
        title: "السلطات",
        items: withDefaultActive([
            {
                name: "سلطات مشكلة",
                image: "/menu/salad/1.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "ذرة مايونيز ",
                image: "/menu/salad/5.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "بيكانتي ",
                image: "/menu/salad/1.jpeg",
                desc: "ذرة مايونيز / بيكانتي / تركية / ثومية",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "تركية",
                image: "/menu/salad/4.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "ثومية",
                image: "/menu/salad/2.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "ملفوف",
                image: "/menu/salad/3.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "كول سلو",
                image: "/menu/salad/6.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "بطاطا",
                image: "/menu/salad/20.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            }
        ])
    }
};
// Middle Branch Menu (initially same as Gaza, but can be modified independently)
const middleMenu = {
    shawarma: gazaMenu.shawarma,
    italian: gazaMenu.italian,
    sandwiches: gazaMenu.sandwiches,
    easternSweets: gazaMenu.easternSweets,
    westernSweets: gazaMenu.westernSweets,
    barSweets: gazaMenu.barSweets,
    drinks: {
        ...gazaMenu.drinks,
        items: withDefaultActive([
            {
                name: "آيس كريم",
                price: 10,
                image: "/menu/drinks/14.jpg",
                active: true
            },
            {
                name: "براد",
                price: 5,
                image: "/menu/drinks/15.jpg",
                active: true
            },
            ...gazaMenu.drinks.items
        ])
    },
    salads: gazaMenu.salads
};
const branchMenuData = {
    gaza: gazaMenu,
    middle: middleMenu
};
function getMenuByBranch(branch) {
    return branchMenuData[branch] || branchMenuData.gaza;
}
function getCategoryByBranch(branch, categoryId) {
    const menu = getMenuByBranch(branch);
    return menu[categoryId] || null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/O2-Gaza-Project/app/category/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/framer-motion@12.27.0_@emot_ea24378ea94ca90bc41379238f9f0cd6/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/framer-motion@12.27.0_@emot_ea24378ea94ca90bc41379238f9f0cd6/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/shopping-basket.js [app-client] (ecmascript) <export default as ShoppingBasket>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/file-text.js [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/pen-line.js [app-client] (ecmascript) <export default as Edit3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/send.js [app-client] (ecmascript) <export default as Send>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/lucide-react@0.454.0_react@19.2.0/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$product$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/product-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/navbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/components/footer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$branch$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/branch-context.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$cart$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/cart-context.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$menu$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/O2-Gaza-Project/lib/menu-data.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// ================= CONFIGURATION =================
const CONFIG = {
    whatsappNumbers: {
        gaza: "972595201049",
        middle: "972597111811"
    },
    deliveryLocations: {
        gaza: [
            {
                name: "غزة - المدينة",
                price: 5
            },
            {
                name: "غزة - الشمال",
                price: 8
            },
            {
                name: "غزة - الرمال",
                price: 5
            },
            {
                name: "غزة - الشيخ رضوان",
                price: 6
            },
            {
                name: "غزة - النصر",
                price: 7
            }
        ],
        middle: [
            {
                name: "النصيرات",
                price: 10
            },
            {
                name: "البريج",
                price: 15
            },
            {
                name: "سوارحة الشرقية",
                price: 15
            },
            {
                name: "سوارحة الغربية",
                price: 15
            },
            {
                name: "الزوايدة",
                price: 20
            },
            {
                name: "المغازي",
                price: 25
            },
            {
                name: "دير البلح",
                price: 30
            }
        ]
    }
};
// ================= LEGACY MENU DATA (FOR FALLBACK) =================
// This is kept for reference/fallback only. Branch-specific menus are in /lib/menu-data.ts
const menuData = {
    shawarma: {
        title: "الشاورما",
        items: [
            {
                name: "بيتا شاورما",
                price: 15,
                image: "/menu/shawarma/54.jpg"
            },
            {
                name: "شاورما عادي",
                price: 15,
                image: "/menu/shawarma/48.jpg"
            },
            {
                name: "فرشوحه دبل",
                price: 17,
                image: "/menu/shawarma/5O1A7108.jpg"
            },
            {
                name: "فرشوحه دبل لحمة",
                price: 23,
                image: "/menu/shawarma/5O1A7124.jpg"
            },
            {
                name: "فرشوحه دبل دبل",
                price: 25,
                image: "https://images.unsplash.com/photo-1542574271-7f3b92e6c821?w=800&q=80",
                delivery: false
            },
            {
                name: "سوري",
                price: 35,
                image: "/menu/shawarma/53.jpg"
            },
            {
                name: "صفيحة",
                price: 38,
                desc: "شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/51.jpg"
            },
            {
                name: "باشكا",
                price: 40,
                desc: "خبزة باشكا - شاورما - جبنة - زيتون - صوص بيكانتي",
                image: "/menu/shawarma/18.jpg"
            },
            {
                name: "شاورما عربي",
                price: 38,
                desc: "قطع شاورما - جبنة - زيتون اسود",
                image: "/menu/shawarma/17.jpg"
            },
            {
                name: "شاورما نابلسي",
                price: 38,
                desc: "شاورما - بطاطا - صوص بيكانتي - جبنة - زيتون اسود",
                image: "/menu/shawarma/19.jpg"
            },
            {
                name: "صحن شاورما كبير",
                price: 30,
                image: "/menu/shawarma/14.jpg"
            },
            {
                name: "صحن شاورما صغير",
                price: 20,
                image: "/menu/shawarma/13.jpg"
            }
        ]
    },
    italian: {
        title: "الإيطالي",
        items: [
            {
                name: "كاليزوني دجاج",
                price: 25,
                desc: "صدر دجاج - جبنة - زيتون - رانش",
                image: "/menu/italian/35.jpg"
            },
            {
                name: "كاليزوني خضار",
                price: 15,
                desc: "فليفلة - بصل - ذرة - مشروم - زيتون",
                image: "/menu/italian/32.jpg"
            },
            {
                name: "بيتزا مكسيكي دجاج",
                price: 25,
                desc: "صدر دجاج - جبنة - زيتون",
                image: "/menu/italian/33.jpg"
            },
            {
                name: "ميجا",
                price: 30,
                desc: "صدر دجاج - فليفلة - مشروم - جرادة - بصل - كريمة طعام",
                image: "/menu/italian/34.jpg"
            },
            {
                name: "بيتزا",
                price: 20,
                desc: "خضار - ذرة - زيتون",
                image: "/menu/italian/32.jpg"
            },
            {
                name: "بيتزا ماما روزا بالاناناس",
                price: 20,
                desc: "أناناس",
                image: "/menu/italian/2.jpg"
            },
            {
                name: "نابولي",
                price: 20,
                desc: "بيتزا بالتونة والزيتون",
                image: "/menu/italian/3.jpg"
            },
            {
                name: "مارجريتا",
                price: 20,
                desc: "جبنة",
                image: "/menu/italian/1.jpg"
            },
            {
                name: "صوص إضافي",
                price: 3,
                image: "https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&q=80"
            }
        ]
    },
    sandwiches: {
        title: "السندويشات الغربية",
        items: [
            {
                name: "زينجر",
                price: 25,
                desc: "شرائح صدر دجاج متبّلة مع بندورة طازجة، جرجير، حلقات بصل",
                image: "/menu/western/44.jpg"
            },
            {
                name: "بيف برجر",
                price: 25,
                desc: "قطعة لحمة - بصل - بندورة - جبنة - مخلل - صوص بيكانتي",
                image: "/menu/western/40.jpg"
            },
            {
                name: "بيغ ماك",
                price: 35,
                desc: "قطعتين لحمة - بصل - بندورة - جبنة - مخلل - صوص بيكانتي",
                image: "/menu/western/46.jpg"
            },
            {
                name: "تشكن بيتزا",
                price: 25,
                desc: "صدر دجاج - مشروم - فليفلة - بصل - زيتون اسود - جبنة",
                image: "/menu/western/42.jpg"
            },
            {
                name: "شيش طاووق",
                price: 25,
                desc: "فخد دجاج - جرجير - بندورة -مخلل -صوص بيكانتي",
                image: "/menu/western/47.jpg"
            },
            {
                name: "فطيرة الذهبية",
                price: 25,
                desc: "صدر دجاج - فليفلة - بصل - زيتون اسود - جبنة - ذرة - كريمة طعام",
                image: "/menu/western/43.jpg"
            }
        ]
    },
    easternSweets: {
        title: "الحلويات الشرقية",
        byWeight: true,
        items: [
            {
                name: "نمورة",
                pricePerKg: 25,
                image: "/menu/sweets/25.jpg"
            },
            {
                name: "معكوفة لوز",
                pricePerKg: 35,
                image: "/menu/sweets/6.jpg"
            },
            {
                name: "سرة",
                pricePerKg: 35,
                image: "/menu/sweets/2.jpg"
            },
            {
                name: "معكوفة عين جمل",
                pricePerKg: 35,
                image: "/menu/sweets/26.jpg"
            },
            {
                name: "وربات",
                pricePerKg: 35,
                image: "/menu/sweets/2.jpg"
            },
            {
                name: "كلاج",
                pricePerKg: 30,
                image: "/menu/sweets/3.jpg"
            },
            {
                name: "عش البلبل",
                pricePerKg: 35,
                image: "/menu/sweets/7.jpg"
            },
            {
                name: "سنيورة",
                pricePerKg: 35,
                image: "/menu/sweets/8.jpg"
            },
            {
                name: "كلّ وشكر",
                pricePerKg: 35,
                image: "/menu/sweets/5.jpg"
            },
            {
                name: "كنافة عربية",
                pricePerKg: 40,
                image: "/menu/sweets/11.jpg"
            },
            {
                name: "بسبوسة نوتيلا",
                pricePerKg: 40,
                image: "/menu/sweets/5K7A6205.jpg"
            },
            {
                name: "بقلاوة عين جمل",
                pricePerKg: 55,
                image: "/menu/sweets/41.jpg"
            },
            {
                name: "بقلاوة لوز",
                pricePerKg: 48,
                image: "/menu/sweets/9.jpg"
            },
            {
                name: "بقلاوة حلبي",
                pricePerKg: 100,
                image: "/menu/sweets/10.jpg"
            },
            {
                name: "أساور لوز",
                pricePerKg: 48,
                image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&q=80"
            },
            {
                name: "أساور كاجو",
                pricePerKg: 48,
                image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&q=80"
            },
            {
                name: "نابلسية",
                pricePerKg: 50,
                image: "/menu/sweets/23.jpg"
            },
            {
                name: "كاسات مكسرات",
                pricePerKg: 80,
                image: "/menu/sweets/24.jpg"
            },
            {
                name: "بورما حلبي",
                pricePerKg: 100,
                image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=800&q=80",
                delivery: false
            },
            {
                name: "بلورية حلبي",
                pricePerKg: 130,
                image: "https://images.unsplash.com/photo-1571167530149-c6f274f6db8f?w=800&q=80"
            },
            {
                name: "دولمة حلبي",
                pricePerKg: 130,
                image: "/menu/sweets/27.jpg"
            }
        ]
    },
    westernSweets: {
        title: "الكيك والحلويات الغربية",
        items: [
            {
                name: "قالب كيك صغير",
                price: 60,
                image: "/menu/cake/9.jpg"
            },
            {
                name: "قالب كيك كبير",
                price: 80,
                image: "/menu/cake/10.jpg"
            },
            {
                name: "قالب كيك سبيشل",
                price: 120,
                image: "/menu/cake/38.jpg"
            },
            {
                name: "سويس رول",
                price: 8,
                image: "/menu/cake/31.jpg"
            },
            {
                name: "تريلتشا",
                price: 10,
                image: "/menu/cake/21.jpg"
            },
            {
                name: "قطع كيك سبيشل",
                price: 15,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/cake/30.jpg"
            },
            {
                name: "سوبريم",
                price: 20,
                desc: "لوتس - نوتيلا - بيستاشيو",
                image: "/menu/cake/28.jpg"
            },
            {
                name: "موس نوتيلا",
                price: 15,
                desc: "كيندر- لوتس - نوتيلا - بيستاشيو",
                image: "/menu/cake/4.jpg"
            },
            {
                name: "تشيس كيك",
                price: 15,
                image: "/menu/cake/7.jpg"
            },
            {
                name: "كرانش بار",
                price: 15,
                image: "/menu/cake/23.jpg"
            },
            {
                name: "قالب نص بلاطة",
                price: 150,
                image: "/menu/cake/8.jpg"
            }
        ]
    },
    barSweets: {
        title: "حلويات البار",
        items: [
            {
                name: "كريب شوكولاتة",
                price: 15,
                image: "/menu/bar/16.jpg"
            },
            {
                name: "كريب (نوتيلا / بيستاشيو / لوتس)",
                price: 30,
                image: "/menu/bar/64.jpg"
            },
            {
                name: "كريب دبي",
                price: 30,
                image: "/menu/bar/14.jpg"
            },
            {
                name: "بان كيك نوتيلا",
                price: 30,
                desc: "نوتيلا / بيستاشيو / لوتس",
                image: "/menu/bar/13.jpg"
            },
            {
                name: "رينجز",
                price: 25,
                image: "/menu/bar/56.jpg"
            },
            {
                name: "لقيمات شوكولاتة",
                price: 15,
                image: "/menu/bar/15.jpg"
            },
            {
                name: "لقيمات (نوتيلا / بيستاشيو / لوتس)",
                price: 30,
                image: "/menu/bar/55.jpg"
            },
            {
                name: "بان كيك شوكولاتة",
                price: 15,
                image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800&q=80"
            },
            {
                name: "مولتن كيك",
                price: 25,
                image: "/menu/bar/37.jpg"
            },
            {
                name: "هوت كيك",
                price: 25,
                image: "/menu/bar/59.jpg"
            },
            {
                name: "براونيز",
                price: 25,
                image: "/menu/bar/38.jpg"
            },
            {
                name: "كنافة نويتلا",
                price: 15,
                image: "/menu/bar/58.jpg"
            }
        ]
    },
    drinks: {
        title: "المشروبات",
        items: [
            {
                name: "عصير الموسم",
                price: 12,
                image: "/menu/drinks/1.jpg"
            },
            {
                name: "عصير أناناس",
                price: 12,
                image: "/menu/drinks/2.jpg"
            },
            {
                name: "ليمون ونعنع",
                price: 12,
                image: "/menu/drinks/3.jpg"
            },
            {
                name: "أفوكادو",
                price: 18,
                image: "/menu/drinks/4.jpg"
            },
            {
                name: "شوكو بارد",
                price: 12,
                image: "/menu/drinks/7.jpg"
            },
            {
                name: "ايس موكا",
                price: 12,
                image: "/menu/drinks/5.jpg"
            },
            {
                name: "آيس كافي",
                price: 12,
                image: "/menu/drinks/10.jpg"
            },
            {
                name: "ميلك شيك",
                price: 15,
                image: "/menu/drinks/8.jpg"
            },
            {
                name: "موهيتو",
                price: 25,
                image: "/menu/drinks/16.jpg"
            },
            {
                name: "آيس كريم",
                price: 10,
                image: "/menu/drinks/14.jpg"
            },
            {
                name: "براد",
                price: 5,
                image: "/menu/drinks/15.jpg"
            },
            {
                name: "نسكافيه",
                price: 7,
                image: "/menu/drinks/9.jpg"
            },
            {
                name: "شاي",
                price: 5,
                image: "/menu/drinks/11.jpg"
            },
            {
                name: "بلو",
                price: 4,
                image: "/menu/drinks/17.jpg"
            },
            {
                name: "كوكا كولا",
                price: 4,
                image: "/menu/drinks/18.jpg"
            },
            {
                name: "سبرايت",
                price: 4,
                image: "/menu/drinks/19.jpg"
            },
            {
                name: "مياه معدنية 200 ملم",
                price: 1,
                image: "/menu/drinks/12.jpg"
            },
            {
                name: "مياه معدنية 500 ملم",
                price: 2,
                image: "/menu/drinks/13.jpg"
            }
        ]
    },
    salads: {
        title: "السلطات",
        items: [
            {
                name: "سلطات مشكلة",
                image: "/menu/salad/1.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "ذرة مايونيز ",
                image: "/menu/salad/5.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "بيكانتي ",
                image: "/menu/salad/1.jpeg",
                desc: "ذرة مايونيز / بيكانتي / تركية / ثومية",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "تركية",
                image: "/menu/salad/4.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "ثومية",
                image: "/menu/salad/2.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "ملفوف",
                image: "/menu/salad/3.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "كول سلو",
                image: "/menu/salad/6.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 15
                    },
                    {
                        name: "وسط",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            },
            {
                name: "بطاطا",
                image: "/menu/salad/20.jpeg",
                variants: [
                    {
                        name: "كبير",
                        price: 10
                    },
                    {
                        name: "صغير",
                        price: 5
                    }
                ]
            }
        ]
    }
};
// Toast Component
function Toast({ message, onClose }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toast.useEffect": ()=>{
            const timer = setTimeout(onClose, 3000);
            return ({
                "Toast.useEffect": ()=>clearTimeout(timer)
            })["Toast.useEffect"];
        }
    }["Toast.useEffect"], [
        onClose
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0,
            y: -50
        },
        animate: {
            opacity: 1,
            y: 0
        },
        exit: {
            opacity: 0,
            y: -50
        },
        className: "fixed top-4 left-1/2 -translate-x-1/2 z-[3000] bg-primary text-primary-foreground px-6 py-3 rounded-xl shadow-2xl font-bold text-center max-w-[90vw]",
        children: message
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 480,
        columnNumber: 5
    }, this);
}
_s(Toast, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Toast;
// Product Modal Component
function ProductModal({ product, isByWeight, onClose, onAddToCart, whatsappNumber }) {
    _s1();
    const [qty, setQty] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [weight, setWeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [priceInput, setPriceInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedVariant, setSelectedVariant] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(product?.variants ? product.variants[0] : null);
    const calculatedPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductModal.useMemo[calculatedPrice]": ()=>{
            if (isByWeight && product?.pricePerKg) {
                return weight * product.pricePerKg;
            }
            if (selectedVariant) {
                return selectedVariant.price * qty;
            }
            return (product?.price || 0) * qty;
        }
    }["ProductModal.useMemo[calculatedPrice]"], [
        isByWeight,
        product,
        weight,
        qty,
        selectedVariant
    ]);
    const canDeliver = product?.delivery !== false;
    const handlePriceInput = (value)=>{
        setPriceInput(value);
        const val = parseFloat(value);
        if (!isNaN(val) && val > 0 && product?.pricePerKg) {
            setWeight(val / product.pricePerKg);
        }
    };
    const handleWeightPreset = (w)=>{
        setWeight(w);
        setPriceInput("");
    };
    const adjustWeight = (delta)=>{
        const newWeight = Math.max(0.25, parseFloat((weight + delta).toFixed(2)));
        setWeight(newWeight);
        setPriceInput("");
    };
    const whatsappText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductModal.useMemo[whatsappText]": ()=>{
            if (!product) return "";
            if (isByWeight && weight > 0) {
                return `أريد طلب: ${product.name} - وزن ${weight.toFixed(2)} كغ (السعر ${calculatedPrice.toFixed(1)} شيكل)`;
            }
            const variantStr = selectedVariant ? ` (${selectedVariant.name})` : "";
            return `أريد طلب: ${product.name}${variantStr} × ${qty}`;
        }
    }["ProductModal.useMemo[whatsappText]"], [
        product,
        isByWeight,
        weight,
        qty,
        calculatedPrice,
        selectedVariant
    ]);
    const handleAddToCart = ()=>{
        if (!product || !canDeliver) return;
        if (isByWeight && (calculatedPrice <= 0 || weight <= 0)) return;
        let finalProduct = product;
        if (selectedVariant) {
            finalProduct = {
                ...product,
                name: `${product.name} - ${selectedVariant.name}`,
                price: selectedVariant.price
            };
        }
        onAddToCart(finalProduct, qty, weight, calculatedPrice, isByWeight);
        onClose();
    };
    if (!product) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "fixed inset-0 bg-black/90 z-[2000] flex items-center justify-center p-3 overflow-y-auto",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                scale: 0.9,
                opacity: 0
            },
            animate: {
                scale: 1,
                opacity: 1
            },
            exit: {
                scale: 0.9,
                opacity: 0
            },
            className: "bg-card rounded-2xl w-full max-w-md overflow-hidden max-h-[90vh] overflow-y-auto my-auto",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative h-48 md:h-64",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: product.image || "/placeholder.svg",
                        alt: product.name,
                        fill: true,
                        className: "object-cover"
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                        lineNumber: 593,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 592,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-5 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "absolute top-4 left-4 text-white/80 hover:text-white text-3xl",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                className: "w-8 h-8"
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 605,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 601,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl md:text-2xl font-bold mb-2",
                            children: product.name
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 608,
                            columnNumber: 11
                        }, this),
                        product.desc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-muted-foreground text-sm mb-3",
                            children: product.desc
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 610,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-2xl md:text-3xl font-extrabold text-primary mb-4",
                            children: [
                                calculatedPrice.toFixed(1),
                                " ₪",
                                isByWeight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm text-muted-foreground font-normal block",
                                    children: [
                                        "(",
                                        weight.toFixed(2),
                                        " كغ × ",
                                        product.pricePerKg,
                                        " ₪/كغ)"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 616,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 613,
                            columnNumber: 11
                        }, this),
                        !canDeliver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-secondary border-2 border-primary rounded-xl p-4 mb-4 flex items-center justify-center gap-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold",
                                children: [
                                    "🚫 هذا المنتج متوفر للطلب من",
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-primary",
                                        children: "المطعم فقط"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 626,
                                        columnNumber: 17
                                    }, this),
                                    " - لا يوجد توصيل"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 624,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 623,
                            columnNumber: 13
                        }, this),
                        isByWeight && canDeliver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-primary/10 border-2 border-primary rounded-xl p-4 mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-right mb-2 font-bold text-sm",
                                    children: "💰 أدخل المبلغ الذي تريد دفعه (شيكل)"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 633,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    value: priceInput,
                                    onChange: (e)=>handlePriceInput(e.target.value),
                                    placeholder: "أدخل السعر",
                                    className: "w-full p-3 bg-white text-black rounded-lg text-center text-xl font-bold shadow-inner focus:outline-none focus:ring-2 focus:ring-primary"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 636,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-4 gap-2 mt-4",
                                    children: [
                                        0.25,
                                        0.5,
                                        0.75,
                                        1
                                    ].map((w)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleWeightPreset(w),
                                            className: `py-2 px-3 border-2 border-primary rounded-lg font-semibold transition-colors ${weight === w && !priceInput ? "bg-primary text-primary-foreground" : "bg-transparent text-white"}`,
                                            children: [
                                                w,
                                                " كغ"
                                            ]
                                        }, w, true, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 645,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 643,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 632,
                            columnNumber: 13
                        }, this),
                        product.variants && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-primary/10 border-2 border-primary rounded-xl p-4 mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-right mb-2 font-bold text-sm",
                                    children: "🏷️ اختر النوع / الحجم"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 659,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-3 gap-2",
                                    children: product.variants.map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setSelectedVariant(v),
                                            className: `py-2 px-1 border-2 border-primary rounded-lg font-semibold transition-colors text-xs md:text-sm ${selectedVariant?.name === v.name ? "bg-primary text-primary-foreground" : "bg-transparent text-white"}`,
                                            children: [
                                                v.name,
                                                " (",
                                                v.price,
                                                " ₪)"
                                            ]
                                        }, v.name, true, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 664,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 662,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 658,
                            columnNumber: 13
                        }, this),
                        canDeliver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center gap-4 mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>isByWeight ? adjustWeight(-1) : setQty(Math.max(1, qty - 1)),
                                    className: "w-11 h-11 rounded-xl border-2 border-primary bg-transparent text-white flex items-center justify-center transition-all active:bg-primary active:scale-90",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 682,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 678,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xl font-extrabold min-w-[80px] text-center",
                                    children: isByWeight ? `${weight.toFixed(2)} كغ` : qty
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 684,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>isByWeight ? adjustWeight(1) : setQty(qty + 1),
                                    className: "w-11 h-11 rounded-xl border-2 border-primary bg-transparent text-white flex items-center justify-center transition-all active:bg-primary active:scale-90",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 691,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 687,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 677,
                            columnNumber: 13
                        }, this),
                        canDeliver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleAddToCart,
                                className: "w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-bold mb-3 transition-all hover:-translate-y-0.5 hover:shadow-lg flex items-center justify-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__["ShoppingBasket"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 702,
                                        columnNumber: 17
                                    }, this),
                                    "أضف إلى السلة"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 698,
                                columnNumber: 15
                            }, this)
                        }, void 0, false)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 600,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 585,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 578,
        columnNumber: 5
    }, this);
}
_s1(ProductModal, "WuUa8R9SwANxxBmI8ft9VSIAxcI=");
_c1 = ProductModal;
// Cart Modal Component
function CartModal({ cart, onClose, onUpdateQty, onClear, onCheckout }) {
    const total = cart.reduce((acc, item)=>acc + item.price * item.qty, 0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "fixed inset-0 bg-black/90 z-[2100] flex items-center justify-center p-3",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                scale: 0.9,
                opacity: 0
            },
            animate: {
                scale: 1,
                opacity: 1
            },
            exit: {
                scale: 0.9,
                opacity: 0
            },
            className: "bg-card rounded-2xl w-full max-w-lg p-5 max-h-[90vh] overflow-y-auto",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xl font-bold mb-5 pb-3 border-b-2 border-primary",
                    children: "سلة الطلبات"
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 745,
                    columnNumber: 9
                }, this),
                cart.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-center text-muted-foreground py-8",
                    children: "السلة فارغة"
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 750,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3",
                    children: cart.map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center bg-white/5 p-3 rounded-xl gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 text-right text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                            children: [
                                                item.name,
                                                item.isByWeight && ` (${item.weight?.toFixed(2)} كغ)`
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 759,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-muted-foreground text-xs",
                                            children: [
                                                "السعر: ",
                                                item.price.toFixed(1),
                                                "₪"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 763,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-primary font-bold",
                                            children: [
                                                "الإجمالي: ",
                                                (item.price * item.qty).toFixed(1),
                                                "₪"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 766,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 758,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 bg-black/30 p-1 rounded-lg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>onUpdateQty(idx, -1),
                                            className: "w-7 h-7 rounded bg-primary text-white flex items-center justify-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 775,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 771,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-bold w-5 text-center text-sm",
                                            children: item.qty
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 777,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>onUpdateQty(idx, 1),
                                            className: "w-7 h-7 rounded bg-primary text-white flex items-center justify-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 784,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 780,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 770,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, item.key, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 754,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 752,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-xl font-extrabold text-primary text-center my-5 p-4 bg-primary/10 rounded-xl",
                    children: [
                        "المجموع: ",
                        total.toFixed(1),
                        " ₪"
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 792,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onCheckout,
                    disabled: cart.length === 0,
                    className: "w-full py-3.5 rounded-xl bg-[#25d366] text-white font-bold mb-3 transition-all hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 801,
                            columnNumber: 11
                        }, this),
                        "إتمام الطلب"
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 796,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClear,
                    className: "w-full py-3.5 rounded-xl bg-secondary text-secondary-foreground font-bold mb-3 flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 808,
                            columnNumber: 11
                        }, this),
                        "إفراغ السلة"
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 804,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClose,
                    className: "w-full py-2.5 text-muted-foreground hover:text-foreground transition-colors",
                    children: "إغلاق"
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 811,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 738,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 731,
        columnNumber: 5
    }, this);
}
_c2 = CartModal;
// Customer Form Modal Component
function CustomerFormModal({ onClose, onBack, onSubmit, deliveryLocations, branch, initialData }) {
    _s2();
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData?.name || "");
    const [phone, setPhone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData?.phone || "");
    const [address, setAddress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData?.address || "");
    const [locationName, setLocationName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData?.location?.name || "");
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData?.notes || "");
    const locations = deliveryLocations[branch] || [];
    const selectedLocation = locations.find((l)=>l.name === locationName);
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (!name || !phone || !address || !selectedLocation) return;
        onSubmit({
            name,
            phone,
            address,
            location: selectedLocation,
            notes
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "fixed inset-0 bg-black/90 z-[2100] flex items-center justify-center p-3",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                scale: 0.9,
                opacity: 0
            },
            animate: {
                scale: 1,
                opacity: 1
            },
            exit: {
                scale: 0.9,
                opacity: 0
            },
            className: "bg-card rounded-2xl w-full max-w-lg p-5 max-h-[90vh] overflow-y-auto",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xl font-bold mb-5 text-center flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                            className: "w-6 h-6 text-primary"
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 887,
                            columnNumber: 11
                        }, this),
                        "معلومات التوصيل"
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 886,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    onSubmit: handleSubmit,
                    className: "space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block mb-1 font-semibold text-muted-foreground text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                            className: "w-4 h-4 inline ml-1"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 894,
                                            columnNumber: 15
                                        }, this),
                                        "الاسم الكامل *"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 893,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    value: name,
                                    onChange: (e)=>setName(e.target.value),
                                    placeholder: "أدخل اسمك",
                                    required: true,
                                    className: "w-full p-3 rounded-xl border border-primary/30 bg-white/5 text-white transition-colors focus:outline-none focus:border-primary focus:bg-white/10"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 897,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 892,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block mb-1 font-semibold text-muted-foreground text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                            className: "w-4 h-4 inline ml-1"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 909,
                                            columnNumber: 15
                                        }, this),
                                        "رقم الهاتف *"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 908,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "tel",
                                    value: phone,
                                    onChange: (e)=>setPhone(e.target.value),
                                    placeholder: "059XXXXXXXX",
                                    required: true,
                                    maxLength: 10,
                                    className: "w-full p-3 rounded-xl border border-primary/30 bg-card text-white appearance-none cursor-pointer transition-colors focus:outline-none focus:border-primary"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 912,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 907,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block mb-1 font-semibold text-muted-foreground text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                            className: "w-4 h-4 inline ml-1"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 925,
                                            columnNumber: 15
                                        }, this),
                                        "منطقة التوصيل *"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 924,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: locationName,
                                    onChange: (e)=>setLocationName(e.target.value),
                                    required: true,
                                    className: "w-full p-3 rounded-xl border border-primary/30 bg-card text-white appearance-none cursor-pointer transition-colors focus:outline-none focus:border-primary",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "-- اختر المنطقة --"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 934,
                                            columnNumber: 15
                                        }, this),
                                        locations.map((loc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: loc.name,
                                                children: [
                                                    loc.name,
                                                    " - رسوم التوصيل: ",
                                                    loc.price,
                                                    " ₪"
                                                ]
                                            }, loc.name, true, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 936,
                                                columnNumber: 17
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 928,
                                    columnNumber: 13
                                }, this),
                                selectedLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-2 p-3 bg-primary/10 border-2 border-primary rounded-xl text-center font-bold text-primary",
                                    children: [
                                        "رسوم التوصيل: ",
                                        selectedLocation.price,
                                        " ₪"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 942,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 923,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block mb-1 font-semibold text-muted-foreground text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                            className: "w-4 h-4 inline ml-1"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 950,
                                            columnNumber: 15
                                        }, this),
                                        "العنوان بالتفصيل *"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 949,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    value: address,
                                    onChange: (e)=>setAddress(e.target.value),
                                    placeholder: "مثال: حي الشيخ رضوان، شارع الجلاء، بجانب مسجد...",
                                    required: true,
                                    rows: 3,
                                    className: "w-full p-3 rounded-xl border border-primary/30 bg-white/5 text-white resize-y transition-colors focus:outline-none focus:border-primary focus:bg-white/10"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 953,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 948,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block mb-1 font-semibold text-muted-foreground text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                                            className: "w-4 h-4 inline ml-1"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 965,
                                            columnNumber: 15
                                        }, this),
                                        "ملاحظات الطلب (اختياري)"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 964,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    value: notes,
                                    onChange: (e)=>setNotes(e.target.value),
                                    placeholder: "مثال: بدون بصل، إضافة جبنة زيادة، طلب خاص...",
                                    rows: 3,
                                    className: "w-full p-3 rounded-xl border border-primary/30 bg-white/5 text-white resize-y transition-colors focus:outline-none focus:border-primary focus:bg-white/10"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 968,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 963,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            className: "w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-bold transition-all hover:-translate-y-0.5 hover:shadow-lg flex items-center justify-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 981,
                                    columnNumber: 13
                                }, this),
                                "تاكيد الطلب"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 977,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 891,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onBack,
                    className: "w-full py-3.5 rounded-xl bg-secondary text-secondary-foreground font-bold mt-3 flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 990,
                            columnNumber: 11
                        }, this),
                        "العودة للسلة"
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 986,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 879,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 872,
        columnNumber: 5
    }, this);
}
_s2(CustomerFormModal, "H/myBbFXZCvrHbXcLjGObiccLv8=");
_c3 = CustomerFormModal;
// Confirmation Modal with Invoice
function ConfirmationModal({ cart, customerInfo, location, branch, onClose, onEdit, onSend, onChangeBranch, notes = "" }) {
    const itemsTotal = cart.reduce((acc, item)=>acc + item.price * item.qty, 0);
    const grandTotal = itemsTotal + location.price;
    const branchName = branch === "gaza" ? "محافظة غزة" : "المحافظة الوسطى";
    const fullAddress = `${branchName} - ${location.name} - ${customerInfo.address}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "fixed inset-0 bg-black/90 z-[2100] flex items-center justify-center p-3",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                scale: 0.9,
                opacity: 0
            },
            animate: {
                scale: 1,
                opacity: 1
            },
            exit: {
                scale: 0.9,
                opacity: 0
            },
            className: "bg-card rounded-2xl w-full max-w-lg p-4 max-h-[90vh] overflow-y-auto border-2 border-primary",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClose,
                    className: "float-left text-white/80 hover:text-white",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                        className: "w-6 h-6"
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                        lineNumber: 1044,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1040,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xl font-bold mb-4 text-primary flex items-center gap-2 clear-both",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                            className: "w-6 h-6"
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1047,
                            columnNumber: 11
                        }, this),
                        "تأكيد الطلب"
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1046,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white text-black rounded-xl p-4 mb-4 overflow-x-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center border-b-2 border-dashed border-gray-300 pb-4 mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-primary text-xl font-bold",
                                    children: [
                                        "🍽️ O",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("sub", {
                                            children: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1055,
                                            columnNumber: 20
                                        }, this),
                                        " Restaurant"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1054,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-500 text-sm",
                                    children: "فاتورة طلب توصيل"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1057,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1053,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-100 p-3 rounded-lg mb-4 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-bold text-gray-700 min-w-[60px]",
                                            children: "👤 الاسم:"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1062,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-600 flex-1",
                                            children: customerInfo.name
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1065,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1061,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-bold text-gray-700 min-w-[60px]",
                                            children: "📱 الهاتف:"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1070,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-600 flex-1",
                                            children: customerInfo.phone
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1073,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1069,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-bold text-gray-700 min-w-[60px]",
                                            children: "📍 العنوان:"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1078,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-600 flex-1 break-words",
                                            children: fullAddress
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1081,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1077,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1060,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: "w-full border-collapse text-xs md:text-sm mb-4 min-w-[280px]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "bg-primary text-white",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "p-2 text-right",
                                                children: "الصنف"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 1090,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "p-2 text-center",
                                                children: "الكمية"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 1091,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "p-2 text-center",
                                                children: "السعر"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 1092,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "p-2 text-center",
                                                children: "المبلغ"
                                            }, void 0, false, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 1093,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 1089,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1088,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    children: [
                                        cart.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "border-b border-gray-200 hover:bg-gray-50",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "p-2 text-right font-semibold max-w-[150px]",
                                                        children: [
                                                            item.name,
                                                            item.isByWeight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "block text-gray-500 text-xs",
                                                                children: [
                                                                    "(",
                                                                    item.weight?.toFixed(2),
                                                                    " كغ)"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                                lineNumber: 1102,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                        lineNumber: 1099,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "p-2 text-center",
                                                        children: item.qty
                                                    }, void 0, false, {
                                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                        lineNumber: 1107,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "p-2 text-center",
                                                        children: item.isByWeight ? `${item.unitPrice} ₪/كغ` : `${item.unitPrice} ₪`
                                                    }, void 0, false, {
                                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                        lineNumber: 1108,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "p-2 text-center",
                                                        children: [
                                                            (item.price * item.qty).toFixed(1),
                                                            " ₪"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                        lineNumber: 1113,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, item.key, true, {
                                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                lineNumber: 1098,
                                                columnNumber: 17
                                            }, this)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            className: "bg-amber-50 border-b-2 border-primary",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-2 text-right font-semibold text-orange-600",
                                                    children: "🚚 رسوم التوصيل"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                    lineNumber: 1119,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-2 text-center text-orange-600",
                                                    children: "-"
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                    lineNumber: 1122,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-2 text-center text-orange-600",
                                                    children: location.name
                                                }, void 0, false, {
                                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                    lineNumber: 1123,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-2 text-center font-semibold text-orange-600",
                                                    children: [
                                                        location.price,
                                                        " ₪"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                                    lineNumber: 1126,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1118,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1096,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1087,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gradient-to-l from-primary to-red-500 text-white p-3 rounded-xl flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm",
                                    children: "إجمالي الفاتورة"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1134,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-2xl font-extrabold",
                                    children: [
                                        grandTotal.toFixed(1),
                                        " ₪"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1135,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1133,
                            columnNumber: 11
                        }, this),
                        notes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-blue-50 border-2 border-blue-300 rounded-xl p-3 mt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-bold text-blue-900 text-sm mb-1",
                                    children: "📝 ملاحظات الطلب:"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1142,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-700 text-sm whitespace-pre-wrap",
                                    children: notes
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1143,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1141,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mt-4 pt-4 border-t-2 border-dashed border-gray-300 text-gray-500 text-xs",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "شكراً لطلبكم من O2 Restaurant 🙏"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1148,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "سيتم التواصل معكم قريباً"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1149,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1147,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1052,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onEdit,
                                className: "flex-1 py-3 rounded-xl bg-secondary text-secondary-foreground font-bold flex items-center justify-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__["Edit3"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 1159,
                                        columnNumber: 15
                                    }, this),
                                    "تعديل"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 1155,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onSend,
                                className: "flex-1 py-3 rounded-xl bg-[#25d366] text-white font-bold flex items-center justify-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__["Send"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 1166,
                                        columnNumber: 15
                                    }, this),
                                    "إرسال الطلب"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 1162,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                        lineNumber: 1154,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1153,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 1033,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 1026,
        columnNumber: 5
    }, this);
}
_c4 = ConfirmationModal;
function CategoryPageContent({ defaultBranch }) {
    _s3();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const categoryId = params.id;
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [selectedProduct, setSelectedProduct] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isCartOpen, setIsCartOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCustomerFormOpen, setIsCustomerFormOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isConfirmationOpen, setIsConfirmationOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { cart, addToCart: addToGlobalCart, clearCart, updateQty } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$cart$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    const [customerInfo, setCustomerInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: "",
        phone: "",
        address: ""
    });
    const [selectedLocation, setSelectedLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [orderNotes, setOrderNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Get menu data for the current branch - each branch has independent menu
    const branchMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$menu$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMenuByBranch"])(defaultBranch);
    const categoryData = branchMenu[categoryId];
    const isByWeight = categoryData?.byWeight || false;
    const handleChangeBranch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleChangeBranch]": ()=>{
            router.push("/select-branch");
        }
    }["CategoryPageContent.useCallback[handleChangeBranch]"], [
        router
    ]);
    const getWhatsAppNumber = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[getWhatsAppNumber]": ()=>{
            return defaultBranch && CONFIG.whatsappNumbers[defaultBranch] || CONFIG.whatsappNumbers.middle;
        }
    }["CategoryPageContent.useCallback[getWhatsAppNumber]"], [
        defaultBranch
    ]);
    const showToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[showToast]": (msg)=>{
            setToast(msg);
        }
    }["CategoryPageContent.useCallback[showToast]"], []);
    const handleAddToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleAddToCart]": (product, qty, weight, price, isByWeight)=>{
            if (product.delivery === false) {
                showToast("هذا المنتج غير متاح للتوصيل");
                return;
            }
            const itemKey = isByWeight ? `${product.name}-${weight}` : product.name;
            addToGlobalCart({
                key: itemKey,
                name: product.name,
                price: isByWeight ? price : product.price,
                unitPrice: isByWeight ? product.pricePerKg : product.price,
                qty: isByWeight ? 1 : qty,
                weight: isByWeight ? weight : null,
                isByWeight
            });
            showToast(`تم إضافة ${product.name} إلى السلة`);
        }
    }["CategoryPageContent.useCallback[handleAddToCart]"], [
        addToGlobalCart,
        showToast
    ]);
    const handleUpdateCartQty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleUpdateCartQty]": (index, change)=>{
            const item = cart[index];
            if (item) {
                updateQty(item.key, item.qty + change);
            }
        }
    }["CategoryPageContent.useCallback[handleUpdateCartQty]"], [
        cart,
        updateQty
    ]);
    const handleClearCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleClearCart]": ()=>{
            clearCart();
        }
    }["CategoryPageContent.useCallback[handleClearCart]"], [
        clearCart
    ]);
    const handleCheckout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleCheckout]": ()=>{
            // التحقق من وقت العمل (من 10 صباحاً حتى 12 ليلاً)
            const now = new Date();
            const currentHour = now.getHours();
            // وقت العمل من 10 صباحاً (10) حتى 6 مساءً (18)
            if (currentHour >= 10 && currentHour < 22) {} else {
                showToast("عذراً، المطعم مغلق حالياً. أوقات العمل من 10:00 صباحاً حتى 12:00 ليلاً.");
                return;
            }
            if (cart.length === 0) {
                showToast("السلة فارغة");
                return;
            }
            setIsCartOpen(false);
            setIsCustomerFormOpen(true);
        }
    }["CategoryPageContent.useCallback[handleCheckout]"], [
        cart.length,
        showToast
    ]);
    const handleCustomerSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleCustomerSubmit]": (data)=>{
            setCustomerInfo({
                name: data.name,
                phone: data.phone,
                address: data.address
            });
            setSelectedLocation(data.location);
            setOrderNotes(data.notes);
            setIsCustomerFormOpen(false);
            setIsConfirmationOpen(true);
        }
    }["CategoryPageContent.useCallback[handleCustomerSubmit]"], []);
    const handleSendOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CategoryPageContent.useCallback[handleSendOrder]": ()=>{
            if (!selectedLocation) return;
            let itemsTotal = 0;
            const provinceName = defaultBranch === "gaza" ? "محافظة غزة" : "المحافظة الوسطى";
            const fullAddress = `${provinceName} - ${selectedLocation.name} - ${customerInfo.address}`;
            const targetNumber = getWhatsAppNumber();
            let msg = "🍽️ *طلب جديد من O2 Restaurant*\n━━━━━━━━━━━━━━\n\n";
            msg += `👤 *بيانات العميل:*\n`;
            msg += `• الاسم: ${customerInfo.name}\n`;
            msg += `• الهاتف: ${customerInfo.phone}\n`;
            msg += `• العنوان: ${fullAddress}\n\n`;
            msg += "📋 *تفاصيل الطلب:*\n";
            msg += "┌────────────────────────┐\n";
            cart.forEach({
                "CategoryPageContent.useCallback[handleSendOrder]": (i)=>{
                    const itemTotal = i.price * i.qty;
                    itemsTotal += itemTotal;
                    const displayName = i.isByWeight ? `${i.name} (${i.weight?.toFixed(2)} كغ)` : i.name;
                    const unitPriceDisplay = i.isByWeight ? `${i.unitPrice} ₪/كغ` : `${i.unitPrice} ₪`;
                    msg += `│ ${displayName}\n`;
                    msg += `│   الكمية: ${i.qty} | السعر: ${unitPriceDisplay}\n`;
                    msg += `│   المبلغ: ${itemTotal.toFixed(1)} ₪\n`;
                    msg += `├────────────────────────┤\n`;
                }
            }["CategoryPageContent.useCallback[handleSendOrder]"]);
            msg += `│ 🚚 رسوم التوصيل: ${selectedLocation.price} ₪\n`;
            msg += `└────────────────────────┘\n\n`;
            if (orderNotes) {
                msg += `📝 *ملاحظات الطلب:*\n${orderNotes}\n\n`;
            }
            msg += `━━━━━━━━━━━━━━\n`;
            msg += `💵 *إجمالي الفاتورة: ${(itemsTotal + selectedLocation.price).toFixed(1)} ₪*`;
            window.open(`https://wa.me/${targetNumber}?text=${encodeURIComponent(msg)}`);
            // Reset state
            setCustomerInfo({
                name: "",
                phone: "",
                address: ""
            });
            setOrderNotes("");
            setIsConfirmationOpen(false);
        }
    }["CategoryPageContent.useCallback[handleSendOrder]"], [
        cart,
        customerInfo,
        selectedLocation,
        orderNotes,
        getWhatsAppNumber
    ]);
    const cartTotal = cart.reduce((acc, item)=>acc + item.qty, 0);
    const currentProvince = defaultBranch;
    if (!categoryData) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "min-h-screen bg-background",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Navbar"], {}, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1357,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pt-32 pb-20 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl text-muted-foreground",
                            children: "القسم غير موجود"
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1359,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/categories",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                className: "mt-4 bg-primary text-primary-foreground hover:bg-primary/90 gap-2 bg-transparent",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                        className: "w-4 h-4"
                                    }, void 0, false, {
                                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                        lineNumber: 1362,
                                        columnNumber: 15
                                    }, this),
                                    "الأقسام"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 1361,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1360,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1358,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Footer"], {}, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1367,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 1356,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Navbar"], {}, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1374,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pt-20 md:pt-28 pb-20 md:pb-24",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: -10
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.4
                            },
                            className: "sticky top-[64px] md:top-[80px] z-[1000] py-3 mb-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/categories",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "outline",
                                    className: "text-foreground bg-primary border-primary hover:text-amber-50 hover:bg-primary/90 gap-2  ",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                            lineNumber: 1390,
                                            columnNumber: 17
                                        }, this),
                                        "الأقسام"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1386,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                lineNumber: 1385,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1378,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.6
                            },
                            className: "text-center mb-12 md:mb-16",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-primary text-xs md:text-sm font-semibold tracking-wider mb-2 block uppercase",
                                    children: categoryId
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1403,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4",
                                    children: categoryData.title
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1406,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-muted-foreground text-base md:text-lg max-w-2xl mx-auto",
                                    children: "اختر من مجموعة متنوعة من المنتجات الطازجة والمميزة"
                                }, void 0, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1409,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1397,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            transition: {
                                duration: 0.5,
                                delay: 0.2
                            },
                            className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5 lg:gap-6",
                            children: categoryData.items.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$product$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                                    item: item,
                                    index: index,
                                    onClick: ()=>setSelectedProduct(item),
                                    byWeight: isByWeight
                                }, item.name, false, {
                                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                                    lineNumber: 1422,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                            lineNumber: 1415,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1376,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1375,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIsCartOpen(true),
                className: "fixed bottom-6 left-6 w-14 h-14 md:w-16 md:h-16 bg-primary rounded-full flex items-center justify-center text-white shadow-md hover:shadow-lg transition-all active:scale-[0.98] z-[1500]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$454$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__["ShoppingBasket"], {
                        className: "w-6 h-6 md:w-7 md:h-7"
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                        lineNumber: 1438,
                        columnNumber: 9
                    }, this),
                    cartTotal > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute -top-1 -right-1 w-6 h-6 bg-white text-primary rounded-full text-xs font-bold flex items-center justify-center",
                        children: cartTotal
                    }, void 0, false, {
                        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                        lineNumber: 1440,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1434,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: selectedProduct && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ProductModal, {
                    product: selectedProduct,
                    isByWeight: isByWeight,
                    onClose: ()=>setSelectedProduct(null),
                    onAddToCart: handleAddToCart,
                    whatsappNumber: getWhatsAppNumber()
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1449,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1447,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isCartOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CartModal, {
                    cart: cart,
                    onClose: ()=>setIsCartOpen(false),
                    onUpdateQty: handleUpdateCartQty,
                    onClear: handleClearCart,
                    onCheckout: handleCheckout
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1462,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1460,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isCustomerFormOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomerFormModal, {
                    onClose: ()=>setIsCustomerFormOpen(false),
                    onBack: ()=>{
                        setIsCustomerFormOpen(false);
                        setIsCartOpen(true);
                    },
                    onSubmit: handleCustomerSubmit,
                    deliveryLocations: CONFIG.deliveryLocations,
                    branch: defaultBranch,
                    initialData: {
                        name: customerInfo.name,
                        phone: customerInfo.phone,
                        address: customerInfo.address,
                        location: selectedLocation,
                        notes: orderNotes
                    }
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1475,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1473,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isConfirmationOpen && selectedLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfirmationModal, {
                    cart: cart,
                    customerInfo: customerInfo,
                    location: selectedLocation,
                    branch: defaultBranch,
                    notes: orderNotes,
                    onClose: ()=>setIsConfirmationOpen(false),
                    onEdit: ()=>{
                        setIsConfirmationOpen(false);
                        setIsCustomerFormOpen(true);
                    },
                    onSend: handleSendOrder,
                    onChangeBranch: handleChangeBranch
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1498,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1496,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$27$2e$0_$40$emot_ea24378ea94ca90bc41379238f9f0cd6$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: toast && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Toast, {
                    message: toast,
                    onClose: ()=>setToast(null)
                }, void 0, false, {
                    fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                    lineNumber: 1518,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1516,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$components$2f$footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Footer"], {}, void 0, false, {
                fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
                lineNumber: 1525,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 1373,
        columnNumber: 5
    }, this);
}
_s3(CategoryPageContent, "2X9D/CWhQ2KcjeEd45x07YrfRZU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$cart$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"]
    ];
});
_c5 = CategoryPageContent;
function BranchDetector() {
    _s4();
    const { selectedBranch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$branch$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBranch"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    // Redirect to select branch if no branch selected
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BranchDetector.useEffect": ()=>{
            if (!selectedBranch) {
                router.push("/select-branch");
            }
        }
    }["BranchDetector.useEffect"], [
        selectedBranch,
        router
    ]);
    if (!selectedBranch) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryPageContent, {
        defaultBranch: selectedBranch
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 1545,
        columnNumber: 10
    }, this);
}
_s4(BranchDetector, "TKCzJNXXLspqnYrwxrQfzzytDxM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$lib$2f$branch$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBranch"],
        __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c6 = BranchDetector;
function CategoryPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-screen flex items-center justify-center bg-background",
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 1550,
            columnNumber: 25
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$O2$2d$Gaza$2d$Project$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$10_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BranchDetector, {}, void 0, false, {
            fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
            lineNumber: 1551,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/O2-Gaza-Project/app/category/[id]/page.tsx",
        lineNumber: 1550,
        columnNumber: 5
    }, this);
}
_c7 = CategoryPage;
const __TURBOPACK__default__export__ = CategoryPage;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7;
__turbopack_context__.k.register(_c, "Toast");
__turbopack_context__.k.register(_c1, "ProductModal");
__turbopack_context__.k.register(_c2, "CartModal");
__turbopack_context__.k.register(_c3, "CustomerFormModal");
__turbopack_context__.k.register(_c4, "ConfirmationModal");
__turbopack_context__.k.register(_c5, "CategoryPageContent");
__turbopack_context__.k.register(_c6, "BranchDetector");
__turbopack_context__.k.register(_c7, "CategoryPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=O2-Gaza-Project_af2d5671._.js.map