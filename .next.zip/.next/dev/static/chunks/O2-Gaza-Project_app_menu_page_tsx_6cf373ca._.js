(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/O2-Gaza-Project_f852ed74._.js",
  "static/chunks/5f8e7_4659fa3a._.js"
],
    source: "dynamic"
});
