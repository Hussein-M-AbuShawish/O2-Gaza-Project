(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/O2-Gaza-Project_af2d5671._.js",
  "static/chunks/5f8e7_motion-dom_dist_es_bd0553e6._.js",
  "static/chunks/5f8e7_framer-motion_dist_es_d7253b09._.js",
  "static/chunks/5f8e7_next_ca64598f._.js",
  "static/chunks/5f8e7_tailwind-merge_dist_bundle-mjs_mjs_87444dfd._.js",
  "static/chunks/5f8e7_1dbcb6cf._.js"
],
    source: "dynamic"
});
